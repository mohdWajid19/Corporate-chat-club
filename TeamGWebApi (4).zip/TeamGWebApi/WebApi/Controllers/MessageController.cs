﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/users/{userId}/message")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class MessageController : BaseController
    {
        private IMessageService _messageService;

        private ICloudStorageService _cloudStorageService;

        private IHttpContextAccessor _httpContextAccessor;

        public MessageController(IMessageService messageService, ICloudStorageService cloudStorageService, IHttpContextAccessor httpContextAccessor)
        {
            this._messageService = messageService;
            this._cloudStorageService = cloudStorageService;
            this._httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("threads")]
        public IEnumerable<Message> GetThreadChat(Guid userId)
        {
            return this._messageService.GetThreadChat(userId);
        }

        [HttpGet("club")]
        public ClubChat GetClubChat(Guid userId)
        {
            return this._messageService.GetClubChat(userId);
        }

        [HttpPost("uploadattachments")]
        public List<Attachment> UploadFiles()
        {
            var files = this._httpContextAccessor.HttpContext.Request.Form.Files.ToList();
            return this._cloudStorageService.UploadFilesToStorage(files);
        }

        [HttpPost("send")]
        public void Send([FromBody] Message message)
        {
            if (message.ClubId is null)
            {
                this._messageService.SendMessage(message);
                return;
            }

            this._messageService.SendClubMessage(message);
        }

        [HttpPut("club/status/update")]
        public bool UpdateClubMessageStatus(Guid userId)
        {
            return this._messageService.UpdateClubMessageStatus(MessageStatus.Seen, userId);
        }

        [HttpPut("thread/status/update")]
        public bool UpdatethreadMessageStatus(Guid userId)
        {
            return this._messageService.UpdateMessageStatus(MessageStatus.Seen, userId);
        }
    }
}
