﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/clubs")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class ClubRequestsController : BaseController
    {
        private IClubService _clubService;

        public ClubRequestsController(IClubService clubService)
        {
            this._clubService = clubService;
        }

        [HttpPut("{clubId}/join")]
        public bool JoinClub(Guid clubId)
        {
            return this._clubService.HandleJoinClubRequest(clubId);
        }

        [Authorize(Roles = "GlobalAdmin,ClubAdmin")]
        [HttpPut("requests/{requestId}/accept")]
        public bool AcceptRequest(Guid requestId)
        {
            return this._clubService.HandleRequest(requestId, Models.RequestStatus.Accept);
        }

        [Authorize(Roles = "GlobalAdmin,ClubAdmin")]
        [HttpPut("requests/{requestId}/decline")]
        public bool DeclineRequest(Guid requestId)
        {
            return this._clubService.HandleRequest(requestId, Models.RequestStatus.Decline);
        }
    }
}
