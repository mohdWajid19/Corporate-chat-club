﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/connections")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class ConnectionsController : BaseController
    {
        private IConnectionService _connectionService;

        public ConnectionsController(IConnectionService connectionService)
        {
            this._connectionService = connectionService;
        }

        [HttpGet]
        public IEnumerable<ExistingConnectionDetails> GetConnections()
        {
            return this._connectionService.GetAllConnectionDetails();
        }

        [HttpGet("available")]
        public IEnumerable<AvailableConnectionDetails> GetAvailableConnections()
        {
            return this._connectionService.GetAllAvailableNewConnections();
        }

        [HttpGet("threads")]
        public IEnumerable<ThreadListItem> GetThreads()
        {
            return this._connectionService.GetAllUserConnections();
        }

        [HttpPost("add/{receiverId}")]
        public bool AddConnection(Guid receiverId)
        {
            return this._connectionService.AddConnection(receiverId);
        }
    }
}
