﻿using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;
using WebApi.Models;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/authentication")]
    public class AuthenticationController : BaseController
    {
        private IAuthService _authService;

        public AuthenticationController(IAuthService authService)
        {
            this._authService = authService;
        }

        [HttpPost("login")]
        public object Login(UserCredentials credentials)
        {
            return this._authService.LoginUser(credentials);
        }

        [HttpPut("changepassword")]
        public bool ChangePassword(ChangePasswordInput newCredentials)
        {
            return this._authService.ChangePassword(newCredentials);
        }

        [HttpPut("register")]
        public void Register(UserCredentials credentials)
        {
            this._authService.RegisterUser(credentials);
        }
    }
}
