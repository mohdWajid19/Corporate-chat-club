﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/connections/{userId}")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class UserThreadActionsController : BaseController
    {
        private IConnectionService _connectionService;

        public UserThreadActionsController(IConnectionService connectionService)
        {
            this._connectionService = connectionService;
        }

        [HttpPut("toggleblock")]
        public bool ToggleBlock(Guid userId)
        {
            return this._connectionService.ToggleBlockConnection(userId);
        }

        [HttpPut("togglemute")]
        public bool ToggleMute(Guid userId)
        {
            return this._connectionService.ToggleMuteConnection(userId);
        }

        [HttpPut("togglefavourite")]
        public bool ToggleFavourite(Guid userId)
        {
            return this._connectionService.ToggleFavourite(userId);
        }
    }
}
