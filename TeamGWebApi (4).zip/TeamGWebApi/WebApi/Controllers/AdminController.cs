﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/admin")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin")]
    public class AdminController : BaseController
    {
        private IAdminUserService _adminUserService;

        private IAdminClubService _adminClubService;

        private IClubService _clubService;

        public AdminController(IAdminUserService adminUserService, IAdminClubService adminClubService, IClubService clubService)
        {
            this._adminClubService = adminClubService;
            this._adminUserService = adminUserService;
            this._clubService = clubService;
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpGet("clubs/inactive")]
        public IEnumerable<InactiveClub> GetInactiveClubs()
        {
            return this._clubService.GetInactiveClubs();
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpPost("users/add")]
        public Guid AddUser([FromBody] AddUserInputs user)
        {
            return this._adminUserService.AddNewUser(user);
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpPut("user/toggleactivation")]
        public bool ToggleUserActivation([FromBody] AdminActionInputs action)
        {
            return this._adminUserService.ToggleUserActivation(action);
        }

        [HttpPut("club/toggleactivation")]
        public bool ToggleClubActivation([FromBody] AdminActionInputs action)
        {
            return this._adminClubService.ToggleClubActivation(action);
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpPut("user/delete")]
        public bool DeleteUser([FromBody] AdminActionInputs action)
        {
            return this._adminUserService.DeleteUser(action);
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpPut("club/delete")]
        public bool DeleteClub([FromBody] AdminActionInputs action)
        {
            return this._adminClubService.DeleteClub(action);
        }
    }
}
