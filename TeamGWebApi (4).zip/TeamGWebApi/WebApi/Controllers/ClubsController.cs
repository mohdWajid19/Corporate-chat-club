﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/clubs")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class ClubsController : BaseController
    {
        private IClubService _clubService;

        private ICloudStorageService _cloudStorageService;

        public ClubsController(IClubService clubService, ICloudStorageService cloudStorageService)
        {
            this._clubService = clubService;
            this._cloudStorageService = cloudStorageService;
        }

        [HttpGet]
        public IEnumerable<ClubMembershipDetails> GetAllClubDetail()
        {
            return this._clubService.GetClubMemberships();
        }

        [HttpGet("{clubId}")]
        public Club GetClub(Guid clubId)
        {
            return this._clubService.GetClub(clubId);
        }

        [HttpGet("{clubId}/participants")]
        public IEnumerable<Participant> GetParticipants(Guid clubId)
        {
            return this._clubService.GetAllParticipants(clubId);
        }

        [HttpGet("{clubId}/requests")]
        public IEnumerable<Request> GetRequests(Guid clubId)
        {
            return this._clubService.GetClubRequests(clubId);
        }

        [HttpPost("uploadimage")]
        public object UploadImage()
        {
            return this._cloudStorageService.UploadImageToStorage();
        }

        [HttpPost("add")]
        public bool AddClub([FromBody] AddClubInputs club)
        {
            return this._clubService.AddClub(club);
        }

        [Authorize(Roles = "GlobalAdmin,ClubAdmin")]
        [HttpPut("edit")]
        public bool EditInfo([FromBody] Club club)
        {
            return this._clubService.EditClubDetails(club);
        }
    }
}