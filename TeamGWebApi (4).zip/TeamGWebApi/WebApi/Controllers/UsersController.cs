﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Models;
using WebApi.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApi.Controllers
{
    [Route("api/users/")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class UsersController : BaseController
    {
        private IUserService _userService;

        private IClubService _clubService;

        public UsersController(IUserService userService, IClubService clubService)
        {
            this._userService = userService;
            this._clubService = clubService;
        }

        [Authorize(Roles = "GlobalAdmin")]
        [HttpGet]
        public IEnumerable<UserClubDetails> GetAllUsers()
        {
            return this._userService.GetAll();
        }

        [HttpGet("{userId}")]
        public User GetUser(Guid userId)
        {
            return this._userService.GetUser(userId);
        }

        [HttpGet("clubs")]
        public IEnumerable<ClubChatListItem> GetClubs()
        {
            return this._clubService.GetClubChatList();
        }

        [HttpGet("{userId}/profile")]
        public UserDetails GetUserProfile([FromRoute] Guid userId)
        {
            return this._userService.GetUserDetails(userId);
        }

        [HttpPut("{userId}/profile/edit")]
        public bool UpdateUserDetails([FromBody] UserDetails details)
        {
            return this._userService.UpdateUserDetails(details);
        }
    }
}
