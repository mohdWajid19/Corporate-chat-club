﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/clubs/{clubId}")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin,User")]
    public class UserClubActionsController : BaseController
    {
        private IClubService _clubService;

        public UserClubActionsController(IClubService clubService)
        {
            this._clubService = clubService;
        }

        [HttpPut("report")]
        public bool ReportClub(Guid clubId)
        {
            return this._clubService.ReportClub(clubId);
        }

        [HttpPut("exit")]
        public bool ExitClub(Guid clubId)
        {
            return this._clubService.ExitClub(clubId);
        }

        [HttpPut("togglemute")]
        public bool ToggleMuteClub(Guid clubId)
        {
            return this._clubService.ToggleMuteClub(clubId);
        }

        [HttpPut("togglefavourite")]
        public bool ToggleFavouriteClub(Guid clubId)
        {
            return this._clubService.ToggleFavouriteClub(clubId);
        }
    }
}
