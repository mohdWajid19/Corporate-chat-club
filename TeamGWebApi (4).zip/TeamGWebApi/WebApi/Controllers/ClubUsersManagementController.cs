﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApi.Services;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/clubs/{clubId}/")]
    [Authorize(Roles = "GlobalAdmin,ClubAdmin")]
    public class ClubUsersManagementController : BaseController
    {
        private IClubService _clubService;

        public ClubUsersManagementController(IClubService clubService)
        {
            this._clubService = clubService;
        }

        [HttpGet("nonparticipants")]
        public IEnumerable<ClubNonParticipantsDetails> GetNonParticipants([FromRoute] Guid clubId)
        {
            return this._clubService.GetClubNonParticipants(clubId);
        }

        [HttpPost("participants/add")]
        public bool AddParticipants(Guid clubId, [FromBody] List<Guid> users)
        {
            return this._clubService.AddParticipants(clubId, users);
        }

        [HttpPut("users/{userId}/toggleblock")]
        public bool BlockUser(Guid clubId, Guid userId)
        {
            return this._clubService.ToggleBlockUser(clubId, userId);
        }

        [HttpPut("users/{userId}/removeadmin")]
        public bool RemoveAsAdmin(Guid clubId, Guid userId)
        {
            return this._clubService.RemoveAdmin(clubId, userId);
        }

        [HttpPut("users/{userId}/makeadmin")]
        public bool MakeAsAdmin(Guid clubId, Guid userId)
        {
            return this._clubService.MakeClubAdmin(clubId, userId);
        }
    }
}
