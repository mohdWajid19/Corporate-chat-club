﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebApi.Data
{
    [Table("[UserClubDetails]")]
    public class UserClubDetails : User
    {
        public string AddedByUserName { get; set; }

        public int ActiveClubsCount { get; set; }
    }
}
