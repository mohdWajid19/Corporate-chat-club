﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebApi.Data
{
    [Table("[UserDetails]")]
    public class UserDetails : User
    {
        public string ProfileImageUrl { get; set; }

        public byte Gender { get; set; }

        public DateTime DOB { get; set; }

        public byte BloodGroup { get; set; }

        public byte MaritalStatus { get; set; }

        public string About { get; set; }

        public string Address { get; set; }

        public string ProfessionalSummary { get; set; }
    }
}