﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[UserClub]")]
    public class UserClub
    {
        [Key]
        public Guid Id { get; set; }

        public Guid ClubId { get; set; }

        public Guid UserId { get; set; }

        public bool IsFavourite { get; set; }

        public bool IsBlocked { get; set; }

        public bool IsMuted { get; set; }

        public bool IsDeleted { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
