﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[User]")]
    public class User
    {
        [Key]
        public Guid Id { get; set; }

        public string FirstName { get; set; }

        public string? MiddleName { get; set; }

        public string LastName { get; set; }

        public string DisplayName { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public byte Status { get; set; }

        public Guid? ActionTakenBy { get; set; }

        public DateTime? ActionTakenOn { get; set; }

        public string? Reason { get; set; }

        public bool IsDeleted { get; set; }

        public Guid AddedBy { get; set; }

        public DateTime AddedOn { get; set; }

        public byte Role { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
