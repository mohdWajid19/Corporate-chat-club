﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[UserProfile]")]
    public class UserProfile
    {
        [Key]
        public Guid Id { get; set; }

        public Guid UserId { get; set; }

        public string? ProfileImageUrl { get; set; }

        public byte Gender { get; set; }

        public DateOnly? DOB { get; set; }

        public byte BloodGroup { get; set; }

        public byte MaritalStatus { get; set; }

        public string About { get; set; }

        public string Address { get; set; }

        public string ProfessionalSummary { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
