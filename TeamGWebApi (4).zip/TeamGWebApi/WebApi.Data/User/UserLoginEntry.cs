﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[UserLogin]")]
    public class UserLoginEntry
    {
        [Key]
        public Guid Id { get; set; }

        public string UserName { get; set; }

        public byte[] PasswordHash { get; set; }

        public byte[] PasswordSalt { get; set; }

        public bool IsDeleted { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}