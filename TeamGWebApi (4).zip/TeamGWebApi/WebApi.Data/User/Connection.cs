﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[Connection]")]
    public class Connection
    {
        [Key]
        public Guid Id { get; set; }

        public Guid SenderId { get; set; }

        public Guid ReceiverId { get; set; }

        public bool IsFavourite { get; set; }

        public bool IsBlocked { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsMuted { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
