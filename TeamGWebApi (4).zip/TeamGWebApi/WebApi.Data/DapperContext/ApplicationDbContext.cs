﻿using Dapper;
using Dapper.Contrib.Extensions;
using System.Data;
using System.Data.SqlClient;

namespace WebApi.Data.DapperContext
{
    public class ApplicationDbContext : IApplicationDbContext
    {
        private readonly IDbConnection _connection;

        public ApplicationDbContext(string connectionString)
        {
            _connection = new SqlConnection(connectionString);
        }

        public T Query<T>(string sql, object parameters)
        {
            return _connection.QuerySingleOrDefault<T>(sql, parameters);
        }

        public T GetRecord<T>(Guid id) where T : class
        {
            return _connection.Get<T>(id);
        }

        public IEnumerable<T> GetAllRecords<T>() where T : class
        {
            return _connection.GetAll<T>();
        }

        public IEnumerable<T> GetAllRecords<T>(string sql, object parameters)
        {
            return _connection.Query<T>(sql, parameters);
        }

        public long InsertRecord<T>(T record) where T : class
        {
            return _connection.Insert(record);
        }

        public bool Update<T>(T record) where T : class
        {
            return _connection.Update(record);
        }

        public bool DeleteRecord<T>(T record) where T : class
        {
            return _connection.Delete(record);
        }

        public IEnumerable<T> Execute<T>(string procedureName, object parameters)
        {
            return _connection.Query<T>(procedureName, parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
