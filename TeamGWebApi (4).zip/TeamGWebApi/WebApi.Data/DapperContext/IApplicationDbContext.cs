﻿namespace WebApi.Data.DapperContext
{
    public interface IApplicationDbContext
    {
        public T Query<T>(string sql, object parameters);

        public T GetRecord<T>(Guid id) where T : class;

        public IEnumerable<T> GetAllRecords<T>() where T : class;

        public IEnumerable<T> GetAllRecords<T>(string sql, object parameters);

        public long InsertRecord<T>(T record) where T : class;

        public bool Update<T>(T record) where T : class;

        public bool DeleteRecord<T>(T record) where T : class;

        public IEnumerable<T> Execute<T>(string procedureName, object parameters);
    }
}
