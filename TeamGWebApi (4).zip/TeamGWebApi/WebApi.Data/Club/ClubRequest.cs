﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[ClubRequest]")]
    public class ClubRequest
    {
        [Key]
        public Guid Id { get; set; }

        public Guid ClubId { get; set; }

        public Guid UserId { get; set; }

        public byte RequestStatus { get; set; }

        public Guid? ActionTakenBy { get; set; }

        public DateTime? ActionTakenOn { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
