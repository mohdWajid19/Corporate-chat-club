﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[ComplaintLog]")]
    public class ComplaintLog
    {
        [Key]
        public Guid Id { get; set; }

        public Guid ClubId { get; set; }

        public Guid ReportedBy { get; set; }

        public DateTime ReportedOn { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
