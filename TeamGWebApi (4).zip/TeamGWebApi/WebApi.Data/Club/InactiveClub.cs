﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebApi.Data
{
    [Table("[InactiveClub]")]
    public class InactiveClub : Club
    {
        public String CreatedByName { get; set; }

        public String DeactivatedByName { get; set; }
    }
}