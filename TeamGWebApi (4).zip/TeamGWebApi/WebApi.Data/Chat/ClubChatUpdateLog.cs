﻿using Dapper.Contrib.Extensions;

namespace WebApi.Data
{
    [Table("[ClubChatUpdateLog]")]
    public class ClubChatUpdateLog
    {
        [Key]
        public Guid Id { get; set; }

        public Guid ClubId { get; set; }

        public Guid UpdateBy { get; set; }

        public string Message { get; set; }

        public DateTime TimeStamp { get; set; }

        public Guid CreatedBy { get; set; }

        public DateTime DateCreated { get; set; }

        public Guid? ModifiedBy { get; set; }

        public DateTime? DateModified { get; set; }
    }
}
