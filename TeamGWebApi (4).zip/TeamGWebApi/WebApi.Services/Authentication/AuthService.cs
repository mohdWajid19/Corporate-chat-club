﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using WebApi.Data;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class AuthService : IAuthService
    {
        private readonly IApplicationDbContext _dbContext;

        private readonly IConfiguration _config;

        private readonly IMapper _mapper;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthService(IApplicationDbContext dbContext, IConfiguration configuration, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            this._config = configuration;
            this._dbContext = dbContext;
            this._mapper = mapper;
            this._httpContextAccessor = httpContextAccessor;
        }

        public UserLoginEntry GetUser(string userName)
        {
            return this._dbContext.Query<Data.UserLoginEntry>("SELECT * FROM [dbo].[UserLogin] WHERE [UserName] = @userName and [IsDeleted] = 0 ", new { userName });
        }

        public void RegisterUser(UserCredentials credentials)
        {
            this.CreatePasswordHash(credentials.Password, out byte[] passwordHash, out byte[] passwordSalt);
            var userLogin = new Data.UserLoginEntry() { UserName = credentials.UserName, PasswordHash = passwordHash, PasswordSalt = passwordSalt };
            var user = this._dbContext.Query<Data.User>("SELECT * FROM [dbo].[User] WHERE Email = @email", new { email = credentials.UserName });
            userLogin.SetAuditFieldsOnCreate<Data.UserLoginEntry>(new RequestContext(this._httpContextAccessor) { UserId = user.Id });
            this._dbContext.InsertRecord<Data.UserLoginEntry>(userLogin);
        }

        public object LoginUser(UserCredentials credentials)
        {
            UserLoginEntry user = this.GetUser(credentials.UserName);
            if (user == null || !this.VerifyPassword(user, credentials.Password))
            {
                return null;
            }

            return new { token = CreateToken(user) };
        }

        public bool ChangePassword(ChangePasswordInput changePasswordRequest)
        {
            UserCredentials credentials = _mapper.Map<UserCredentials>(changePasswordRequest);
            if (this.LoginUser(credentials) == null)
            {
                return false;
            }

            UserLoginEntry loginCredentials = this.GetUser(changePasswordRequest.UserName);
            if (VerifyPassword(loginCredentials, changePasswordRequest.NewPassword))
            {
                return false;
            }

            this.CreatePasswordHash(changePasswordRequest.NewPassword, out byte[] passwordHash, out byte[] passwordSalt);
            loginCredentials.PasswordHash = passwordHash;
            loginCredentials.PasswordSalt = passwordSalt;
            var user = this._dbContext.Query<Data.User>("SELECT * FROM [dbo].[User] WHERE Email = @email", new { email = credentials.UserName });
            loginCredentials.SetAuditFieldsOnUpdate<Data.UserLoginEntry>(new RequestContext(this._httpContextAccessor) { UserId = user.Id });
            return this._dbContext.Update(loginCredentials);
        }

        public object CreateToken(UserLoginEntry login)
        {
            Data.User user = this._dbContext.Query<Data.User>("SELECT * FROM [dbo].[User] WHERE [Email] = @email", new { email = login.UserName });
            String role = string.Empty;
            switch (user.Role)
            {
                case (int)Role.GlobalAdmin:
                    role = Role.GlobalAdmin.ToString();
                    break;
                case (int)Role.ClubAdmin:
                    role = Role.ClubAdmin.ToString();
                    break;
                case (int)Role.User:
                    role = Role.User.ToString();
                    break;
                default: break;
            }

            List<Claim> claims = new List<Claim>() {
                new Claim(ClaimTypes.Name, login.UserName),
                new Claim(ClaimTypes.Role, role),
                new Claim("Id", user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Aud, this._config["Jwt:Audience"]),
                new Claim(JwtRegisteredClaimNames.Iss, this._config["Jwt:Issuer"])
            };

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);
            var token = new JwtSecurityToken(
                    issuer: this._config["Issuer"],
                    audience: this._config["Audience"],
                    claims: claims,
                    expires: DateTime.Now.AddDays(1),
                    signingCredentials: creds);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        public bool VerifyPassword(UserLoginEntry loginCredentials, string password)
        {
            using (var hmac = new HMACSHA512(loginCredentials.PasswordSalt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(loginCredentials.PasswordHash);
            }
        }
    }
}