﻿using WebApi.Data;
using WebApi.Models;

namespace WebApi.Services
{
    public interface IAuthService
    {
        public UserLoginEntry GetUser(string userName);

        public void RegisterUser(UserCredentials credentials);

        public object LoginUser(UserCredentials credentials);

        public bool ChangePassword(ChangePasswordInput newCredentials);

        public object CreateToken(UserLoginEntry credentials);

        public void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt);

        public bool VerifyPassword(UserLoginEntry loginCredentials, string password);
    }
}