﻿namespace WebApi.Services
{
    public static class ClubChatUpdateLogExtension
    {
        public static Data.ClubChatUpdateLog BuildLog(this Data.ClubChatUpdateLog source, Guid clubId, Guid userId, string message)
        {
            source.ClubId = clubId;
            source.Message = message;
            source.UpdateBy = userId;
            source.TimeStamp = DateTime.Now;
            source.CreatedBy = userId;
            source.DateCreated = DateTime.Now;
            return source;
        }
    }
}
