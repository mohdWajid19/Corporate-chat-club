﻿    using Newtonsoft.Json;

namespace WebApi.Services
{
    public static class ObjectExtension
    {
        public static string ToJson(this Object source)
        {
            return JsonConvert.SerializeObject(source);
        }

        public static void SetAuditFieldsOnCreate<T>(this object source, RequestContext requestContext) where T : class
        {
            source = source as T;
            typeof(T).GetProperty("CreatedBy").SetValue(source, requestContext.UserId);
            typeof(T).GetProperty("DateCreated").SetValue(source, DateTime.Now);
        }

        public static void SetAuditFieldsOnUpdate<T>(this object source, RequestContext requestContext) where T : class
        {
            source = source as T;
            typeof(T).GetProperty("ModifiedBy").SetValue(source, requestContext.UserId);
            typeof(T).GetProperty("DateModified").SetValue(source, DateTime.Now);
        }
    }
}
