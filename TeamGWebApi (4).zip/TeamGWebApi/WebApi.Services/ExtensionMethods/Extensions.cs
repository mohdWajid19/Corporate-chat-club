﻿namespace WebApi.Services
{
    public class Extensions
    {
        public static void MergeObjects<T>(T updatedData, T originalData, List<string> immutableFields)
        {
            var type = typeof(T);
            var properties = type.GetProperties();
            foreach (var property in properties)
            {
                object value = property.GetValue(updatedData);
                if (!immutableFields.Contains(property.Name) && (value == null || value.ToString() == "0"))
                {
                    value = property.GetValue(originalData);
                }

                property.SetValue(updatedData, value);
            }
        }
    }
}
