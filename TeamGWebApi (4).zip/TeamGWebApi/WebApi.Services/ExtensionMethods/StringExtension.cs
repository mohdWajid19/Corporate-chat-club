﻿using Newtonsoft.Json;

namespace WebApi.Services
{
    public static class StringExtension
    {
        public static T FromJson<T>(this string json)
        {
            return JsonConvert.DeserializeObject<T>(json);
        }
    }
}
