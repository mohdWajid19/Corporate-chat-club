﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class MessageService : IMessageService
    {
        private readonly RequestContext _requestContext;

        private readonly IClubService _clubService;

        private readonly IApplicationDbContext _dbContext;

        private readonly IMapper _mapper;

        public MessageService(RequestContext requestContext, IClubService clubService, IApplicationDbContext dbContext, IMapper mapper)
        {
            this._requestContext = requestContext;
            this._clubService = clubService;
            this._dbContext = dbContext;
            this._mapper = mapper;
        }

        public ClubChat GetClubChat(Guid id)
        {
            return new ClubChat()
            {
                ChatUpdateLogs = this._dbContext.Execute<ChatUpdateLog>("GetChatUpdateLogs", new { clubId = id }).ToList(),
                Messages = this.DeserializeMessages(this._dbContext.Execute<Data.Message>("GetClubMessages", new { clubId = id, receiverId = this._requestContext.UserId }))
            };
        }

        public IEnumerable<Message> GetThreadChat(Guid userId)
        {
            return this.DeserializeMessages(this._dbContext.Execute<Data.Message>("GetThreadMessages", new { senderId = this._requestContext.UserId, receiverId = userId }));
        }

        public void SendClubMessage(Message message)
        {
            this._clubService.GetAllParticipants((Guid)message.ClubId!).ToList()
            .ForEach(participant =>
            {
                message.ReceiverId = participant.Id;
                this.SendMessage(message);
            });
        }

        public void SendMessage(Message message)
        {
            message.SenderId = this._requestContext.UserId;
            message.Status = MessageStatus.Sent;
            if (message.SenderId == message.ReceiverId)
            {
                message.Status = MessageStatus.Seen;
            }

            message.TimeStamp = DateTime.Now;
            var record = this._mapper.Map<Data.Message>(message);
            record.SetAuditFieldsOnCreate<Data.Message>(this._requestContext);
            this._dbContext.InsertRecord(record);
        }

        public bool UpdateClubMessageStatus(MessageStatus status, Guid clubId)
        {
            var messages = this._dbContext.GetAllRecords<Data.Message>("SELECT * FROM [dbo].[Message] WHERE [ClubId] = @clubId AND [ReceiverId] = @receiverId AND [Status] != @status", new { clubId, receiverId = this._requestContext.UserId, status });
            return this.UpdateMessageStatus(messages, status);
        }

        public bool UpdateMessageStatus(MessageStatus status, Guid userId)
        {
            var messages = this._dbContext.GetAllRecords<Data.Message>("SELECT * FROM [dbo].[Message] WHERE [SenderId] = @userId AND [ReceiverId] = @receiverId AND [Status] != @status", new { userId, receiverId = this._requestContext.UserId, status });
            return this.UpdateMessageStatus(messages, status);
        }

        private bool UpdateMessageStatus(IEnumerable<Data.Message> messages, MessageStatus status)
        {
            messages.ToList().ForEach(message =>
            {
                message.Status = Convert.ToByte(status);
                message.SetAuditFieldsOnUpdate<Data.Message>(this._requestContext);
            });

            return this._dbContext.Update(messages);
        }

        private List<Message> DeserializeMessages(IEnumerable<Data.Message> messages)
        {
            var deserializedMessages = new List<Message>();
            messages.ToList().ForEach(message => deserializedMessages.Add(this._mapper.Map<Message>(message)));
            return deserializedMessages;
        }
    }
}
