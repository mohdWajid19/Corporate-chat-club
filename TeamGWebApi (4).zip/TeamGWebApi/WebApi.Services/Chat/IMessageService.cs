﻿using WebApi.Models;

namespace WebApi.Services
{
    public interface IMessageService
    {
        public void SendMessage(Message message);

        public void SendClubMessage(Message message);

        public IEnumerable<Message> GetThreadChat(Guid userId);

        public ClubChat GetClubChat(Guid clubId);

        public bool UpdateMessageStatus(MessageStatus status, Guid userId);

        public bool UpdateClubMessageStatus(MessageStatus status, Guid clubId);
    }
}
