﻿using AutoMapper;
using WebApi.Models;

namespace WebApi.Services
{
    public class Mapper : Profile
    {
        public Mapper()
        {
            this.ConfigureUserMappings();
            this.ConfigureClubMappings();
            this.ConfigureMessageMappings();
        }

        private void ConfigureUserMappings()
        {
            CreateMap<AddUserInputs, Data.User>()
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status));
            CreateMap<UserDetails, Data.User>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (byte)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status))
                .ReverseMap()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (Role)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (UserStatus)src.Status));
            CreateMap<UserDetails, Data.UserProfile>()
                .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => (byte)src.Gender))
                .ForMember(dest => dest.BloodGroup, opt => opt.MapFrom(src => (byte)src.BloodGroup))
                .ForMember(dest => dest.MaritalStatus, opt => opt.MapFrom(src => (byte)src.MaritalStatus));
            CreateMap<Models.User, Data.User>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (byte)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status))
                .ReverseMap()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (Role)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (UserStatus)src.Status));
            CreateMap<Data.UserClubDetails, Models.UserClubDetails>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (Role)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (UserStatus)src.Status));
            CreateMap<Models.UserDetails, Data.UserDetails>()
                .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => (byte)src.Gender))
                .ForMember(dest => dest.BloodGroup, opt => opt.MapFrom(src => (byte)src.BloodGroup))
                .ForMember(dest => dest.MaritalStatus, opt => opt.MapFrom(src => (byte)src.MaritalStatus))
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (byte)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status))
                .ReverseMap()
                .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => (Gender)src.Gender))
                .ForMember(dest => dest.BloodGroup, opt => opt.MapFrom(src => (BloodGroup)src.BloodGroup))
                .ForMember(dest => dest.MaritalStatus, opt => opt.MapFrom(src => (MaritalStatus)src.MaritalStatus))
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (Role)src.Role))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (UserStatus)src.Status));
            CreateMap<UserCredentials, ChangePasswordInput>()
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.UserName))
                .ForMember(dest => dest.OldPassword, opt => opt.MapFrom(src => src.Password))
                .ReverseMap();
        }

        private void ConfigureClubMappings()
        {
            CreateMap<AddClubInputs, Data.Club>()
                .ForMember(dest => dest.Visibility, opt => opt.MapFrom(src => (byte)src.Visibility))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => (byte)src.Type));
            CreateMap<Models.Club, Data.Club>()
                .ForMember(dest => dest.Visibility, opt => opt.MapFrom(src => (byte)src.Visibility))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => (byte)src.Type))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status))
                .ReverseMap()
                .ForMember(dest => dest.Visibility, opt => opt.MapFrom(src => (VisibilityType)src.Visibility))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => (ClubType)src.Type))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (ClubStatus)src.Status));
            CreateMap<Data.InactiveClub, Models.InactiveClub>()
                .ForMember(dest => dest.Visibility, opt => opt.MapFrom(src => (VisibilityType)src.Visibility))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => (ClubType)src.Type))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (ClubStatus)src.Status));
        }

        private void ConfigureMessageMappings()
        {
            CreateMap<Models.Message, Data.Message>()
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (byte)src.Status))
                .ForMember(dest => dest.Attachments, opt => opt.MapFrom(src => src.Attachments.ToJson()))
                .ReverseMap()
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (MessageStatus)src.Status))
                .ForMember(dest => dest.Attachments, opt => opt.MapFrom(src => src.Attachments.FromJson<List<Attachment>>()));
        }
    }
}
