﻿using Microsoft.AspNetCore.Http;
using WebApi.Models;

namespace WebApi.Services
{
    public interface ICloudStorageService
    {
        public List<Attachment> UploadFilesToStorage(List<IFormFile> files);

        public object UploadImageToStorage();
    }
}
