﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using WebApi.Models;
namespace WebApi.Services
{
    public class CloudStorageService : ICloudStorageService
    {
        private readonly BlobContainerClient _container;

        private readonly IHttpContextAccessor _httpContextAccessor;

        public CloudStorageService(string blobStorageConnectionString, string blobStorageContainerName, IHttpContextAccessor httpContextAccessor)
        {
            this._container = new BlobContainerClient(blobStorageConnectionString, blobStorageContainerName);
            this._httpContextAccessor = httpContextAccessor;
        }

        public List<Attachment> UploadFilesToStorage(List<IFormFile>? files)
        {
            var attachments = new List<Attachment>();
            if (files != null)
            {
                foreach (IFormFile file in files)
                {
                    BlobClient client = _container.GetBlobClient(DateTime.Now + file.FileName);
                    using (Stream? data = file.OpenReadStream())
                    {
                        client.Upload(data);
                    }

                    attachments.Add(new Attachment() { FileName = file.FileName, FileDataUrl = client.Uri.AbsoluteUri });
                }
                Task.CompletedTask.Wait();
                return attachments;
            }

            return null;
        }

        public object UploadImageToStorage()
        {
            var forms = this._httpContextAccessor.HttpContext.Request.Form.Files.ToList();
            return new { Url = this.UploadFilesToStorage(forms).SingleOrDefault().FileDataUrl };
        }
    }
}
