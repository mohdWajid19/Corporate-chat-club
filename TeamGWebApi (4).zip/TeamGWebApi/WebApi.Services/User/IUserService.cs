﻿using WebApi.Models;

namespace WebApi.Services
{
    public interface IUserService
    {
        public IEnumerable<UserClubDetails> GetAll();

        public User GetUser(Guid id);

        public UserDetails GetUserDetails(Guid userId);

        public bool UpdateUserDetails(UserDetails userDetails);
    }
}
