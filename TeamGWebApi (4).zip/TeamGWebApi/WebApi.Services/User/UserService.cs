﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class UserService : IUserService
    {
        private readonly RequestContext _requestContext;

        private readonly IApplicationDbContext _dbContext;

        private readonly IMapper _mapper;

        public UserService(RequestContext requestContext, IApplicationDbContext dbContext, IMapper mapper)
        {
            this._requestContext = requestContext;
            this._dbContext = dbContext;
            this._mapper = mapper;
        }

        public bool UpdateUserDetails(UserDetails userDetails)
        {
            var updatedUser = this._mapper.Map<Data.User>(userDetails);
            var updatedUserProfile = this._mapper.Map<Data.UserProfile>(userDetails);
            var originalUser = this._dbContext.GetRecord<Data.User>(updatedUser.Id!);
            var originalUserProfile = this._dbContext.Query<Data.UserProfile>("SELECT * FROM [dbo].[UserProfile] WHERE [UserId] = @userId", new { userId = updatedUser.Id });

            Extensions.MergeObjects<Data.User>(updatedUser, originalUser, new List<string> { "Status", "Role" });
            Extensions.MergeObjects<Data.UserProfile>(updatedUserProfile, originalUserProfile, new List<string> { "MaritalStatus", "BloodGroup", "Gender" });

            updatedUser.SetAuditFieldsOnUpdate<Data.User>(this._requestContext);
            updatedUserProfile.SetAuditFieldsOnUpdate<Data.UserProfile>(this._requestContext);
            return this._dbContext.Update(updatedUser) && this._dbContext.Update(updatedUserProfile);
        }

        public IEnumerable<UserClubDetails> GetAll()
        {
            return this._dbContext.GetAllRecords<Data.UserClubDetails>().Select(record => this._mapper.Map<UserClubDetails>(record));
        }

        public User GetUser(Guid id)
        {
            return this._mapper.Map<User>(this._dbContext.GetRecord<Data.User>(id));
        }

        public UserDetails GetUserDetails(Guid userId)
        {
            var profile = this._mapper.Map<UserDetails>(this._dbContext.GetRecord<Data.UserDetails>(userId));
            if (profile != null)
            {
                return profile;
            }

            return this._mapper.Map<UserDetails>(this._dbContext.GetRecord<Data.User>(userId));
        }
    }
}
