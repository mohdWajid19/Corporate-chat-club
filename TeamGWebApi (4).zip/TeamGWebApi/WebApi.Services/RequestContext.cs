﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace WebApi.Services
{
    public class RequestContext
    {
        public Guid UserId;

        public IHttpContextAccessor? HttpContextAccessor;

        public RequestContext(IHttpContextAccessor httpContextAccessor)
        {
            this.HttpContextAccessor = httpContextAccessor;
        }

        public RequestContext Build()
        {
            var identity = this.HttpContextAccessor.HttpContext?.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                var userId = identity.Claims.FirstOrDefault(claim => claim.Type == "Id").Value;
                if (userId != null)
                {
                    this.UserId = new Guid(userId);
                }
            }

            return this;
        }
    }
}