﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class AdminUserService : AdminService, IAdminUserService
    {
        private readonly IAuthService _authService;

        public AdminUserService(RequestContext requestContext, IMapper mapper, IApplicationDbContext dbContext, IAuthService authService) : base(requestContext, mapper, dbContext)
        {
            this._authService = authService;
        }

        public Guid AddNewUser(AddUserInputs userInputs)
        {
            var user = this._mapper.Map<Data.User>(userInputs);
            if (this._dbContext.Query<Data.User>("SELECT * FROM [dbo].[User] WHERE [Email] = @Email and [IsDeleted] = 0", new { user.Email }) != null)
            {
                return Guid.Empty;
            }

            user.SetAuditFieldsOnCreate<Data.User>(this._requestContext);
            user.AddedBy = this._requestContext.UserId;
            user.AddedOn = DateTime.Now;
            user.Status = Convert.ToByte(userInputs.Status);
            user.Role = Convert.ToByte(Role.User);

            this._dbContext.InsertRecord(user);
            user = this._dbContext.Query<Data.User>("SELECT * FROM [dbo].[User] WHERE [Email] = @Email and [IsDeleted] = 0", new { user.Email });
            this._authService.RegisterUser(new UserCredentials() { UserName = user.Email, Password = "12345" });
            this.AddUserToClubs(user, userInputs.TaggedClubs);

            return user.Id;
        }

        public bool DeleteUser(AdminActionInputs actionFields)
        {
            var user = this.GetObjectWithUpdatedAuditFields<Data.User>(actionFields);
            user.IsDeleted = true;
            this._dbContext.Query<Data.UserClub>("UPDATE [UserClub] SET IsDeleted = 1 where [UserId] = @Id", new { user.Id });
            this._dbContext.Query<Data.ClubAdmin>("UPDATE [ClubAdmin] SET IsDeleted = 1 where [UserId] = @Id", new { user.Id });
            this._dbContext.Query<Data.UserLoginEntry>("UPDATE [UserLogin] SET IsDeleted = 1 where [UserName] = @Email", new { user.Email });
            return this._dbContext.Update(user);
        }

        public bool ToggleUserActivation(AdminActionInputs actionFields)
        {
            var user = this.GetObjectWithUpdatedAuditFields<Data.User>(actionFields);
            user.Status = user.Status == Convert.ToByte(UserStatus.Inactive) ? Convert.ToByte(UserStatus.Active) : Convert.ToByte(UserStatus.Inactive);
            return this._dbContext.Update(user);
        }

        private void AddUserToClubs(Data.User user, List<Guid> taggedClubs)
        {
            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            taggedClubs.ForEach(clubId =>
            {
                this._dbContext.InsertRecord(new Data.UserClub { UserId = user.Id, ClubId = clubId, CreatedBy = contextUser.Id, DateCreated = DateTime.Now });
                this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(clubId, contextUser.Id, $"{contextUser.DisplayName} added {user.DisplayName}"));
            });
        }
    }
}
