﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class AdminClubService : AdminService, IAdminClubService
    {
        public AdminClubService(RequestContext requestContext, IMapper mapper, IApplicationDbContext dbContext) : base(requestContext, mapper, dbContext) { }

        public bool DeleteClub(AdminActionInputs actionFields)
        {
            var club = this.GetObjectWithUpdatedAuditFields<Data.Club>(actionFields);
            club.IsDeleted = true;
            return this._dbContext.Update(club);
        }

        public bool ToggleClubActivation(AdminActionInputs actionFields)
        {
            if (!this.isAuthorizedAdmin(actionFields))
            {
                return false;
            }

            var club = this.GetObjectWithUpdatedAuditFields<Data.Club>(actionFields);
            club.Status = club.Status == Convert.ToByte(ClubStatus.Active) ? Convert.ToByte(ClubStatus.Inactive) : Convert.ToByte(ClubStatus.Active);
            return this._dbContext.Update(club);
        }

        public bool isAuthorizedAdmin(AdminActionInputs actionFields)
        {
            var club = this._dbContext.GetRecord<Data.Club>(actionFields.Id);
            var user = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            var clubAdmins = this._dbContext.GetAllRecords<Data.ClubAdmin>("SELECT * FROM ClubAdmin WHERE ClubId = @Id", new { club.Id });
            foreach (var clubAdmin in clubAdmins)
            {
                if (clubAdmin.UserId == user.Id)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
