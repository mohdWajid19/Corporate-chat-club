﻿using WebApi.Models;

namespace WebApi.Services
{
    public interface IAdminUserService
    {
        public Guid AddNewUser(AddUserInputs user);

        public bool ToggleUserActivation(AdminActionInputs actionFields);

        public bool DeleteUser(AdminActionInputs actionFields);
    }
}
