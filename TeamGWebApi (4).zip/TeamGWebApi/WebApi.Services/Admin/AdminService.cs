﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class AdminService
    {
        protected RequestContext _requestContext { get; private set; }

        protected IApplicationDbContext _dbContext { get; private set; }

        protected IMapper _mapper { get; private set; }

        public AdminService(RequestContext requestContext, IMapper mapper, IApplicationDbContext dbContext)
        {
            this._requestContext = requestContext;
            this._mapper = mapper;
            this._dbContext = dbContext;
        }

        public T GetObjectWithUpdatedAuditFields<T>(AdminActionInputs actionFields) where T : class
        {
            T source = this._dbContext.GetRecord<T>(actionFields.Id);
            typeof(T).GetProperty("ActionTakenBy").SetValue(source, this._requestContext.UserId);
            typeof(T).GetProperty("ActionTakenOn").SetValue(source, DateTime.Now);
            typeof(T).GetProperty("Reason").SetValue(source, actionFields.Reason);
            source.SetAuditFieldsOnUpdate<T>(this._requestContext);
            return source;
        }
    }
}
