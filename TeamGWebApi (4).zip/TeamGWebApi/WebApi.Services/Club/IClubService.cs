﻿using WebApi.Models;

namespace WebApi.Services
{
    public interface IClubService
    {
        public bool AddClub(AddClubInputs club);

        public bool AddParticipants(Guid clubId, List<Guid> participants);

        public IEnumerable<Club> GetAll();

        public Club GetClub(Guid id);

        public IEnumerable<InactiveClub> GetInactiveClubs();

        public IEnumerable<ClubChatListItem> GetClubChatList();

        public IEnumerable<ClubMembershipDetails> GetClubMemberships();

        public IEnumerable<Request> GetClubRequests(Guid clubId);

        public IEnumerable<Participant> GetAllParticipants(Guid clubId);

        public bool MakeClubAdmin(Guid clubId, Guid userId);

        public bool HandleJoinClubRequest(Guid clubId);

        public bool EditClubDetails(Club club);

        public bool HandleRequest(Guid requestId, RequestStatus status);

        public bool ExitClub(Guid clubId);

        public bool RemoveAdmin(Guid clubId, Guid userId);

        public bool ToggleMuteClub(Guid clubId);

        public bool ToggleBlockUser(Guid clubId, Guid userId);

        public bool ToggleFavouriteClub(Guid clubId);

        public bool ReportClub(Guid clubId);

        public IEnumerable<ClubNonParticipantsDetails> GetClubNonParticipants(Guid clubId);
    }
}
