﻿using AutoMapper;
using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class ClubService : IClubService
    {
        private readonly RequestContext _requestContext;

        private readonly IApplicationDbContext _dbContext;

        private readonly IMapper _mapper;

        public ClubService(RequestContext requestContext, IApplicationDbContext dbContext, IMapper mapper)
        {
            this._requestContext = requestContext;
            this._dbContext = dbContext;
            this._mapper = mapper;
        }

        public bool AddClub(AddClubInputs clubInput)
        {
            var club = this._mapper.Map<Data.Club>(clubInput);
            club.OwnerId = this._requestContext.UserId;
            club.CreatedOn = DateTime.Now;
            club.SetAuditFieldsOnCreate<Data.Club>(this._requestContext);
            this._dbContext.InsertRecord(club);
            var clubId = this._dbContext.Query<Guid>("SELECT Id from [dbo].[Club] WHERE [Title] = @Title AND [OwnerId] = @OwnerId", new { club.Title, club.OwnerId });
            if (clubId == Guid.Empty)
            {
                return false;
            }

            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            clubInput.Participants.Add(contextUser.Id);
            clubInput.Admins.Add(contextUser.Id);
            this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(clubId, contextUser.Id, $"{contextUser.DisplayName} Created the club"));
            this.AddParticipants(clubId, clubInput.Participants);
            this.AddParticipants(clubId, clubInput.Admins);
            clubInput.Admins.ForEach(userId => this.MakeClubAdmin(clubId, userId));
            return true;
        }

        public bool AddParticipants(Guid clubId, List<Guid> participants)
        {
            if (participants == null)
            {
                return false;
            }

            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            participants.Where(participantId => participantId != Guid.Empty).ToList().ForEach(participantId =>
            {
                this._dbContext.InsertRecord(this.BuildNewUserClubObject(clubId, participantId));
                if (participantId != this._requestContext.UserId)
                {
                    var user = this._dbContext.GetRecord<Data.User>(participantId);
                    this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(clubId, contextUser.Id, $"{contextUser.DisplayName} added {user.DisplayName}"));
                }
            });

            return true;
        }

        public bool EditClubDetails(Club club)
        {
            var updatedClubData = this._mapper.Map<Data.Club>(club);
            var originalClubData = this._dbContext.GetRecord<Data.Club>(club.Id);
            updatedClubData.SetAuditFieldsOnCreate<Data.Club>(this._requestContext);

            // override the DateCreated to existing date created
            updatedClubData.DateCreated = originalClubData.DateCreated;
            updatedClubData.SetAuditFieldsOnUpdate<Data.Club>(this._requestContext);
            if (!this._dbContext.Update(updatedClubData))
            {
                return false;
            }

            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(club.Id, contextUser.Id, $"{contextUser.DisplayName} Edited the club info"));
            return true;
        }

        public bool ExitClub(Guid clubId)
        {
            var userClub = this.BuildModifiedUserClubObject(clubId, this._requestContext.UserId);
            userClub.IsDeleted = true;
            if (!this._dbContext.Update(userClub))
            {
                return false;
            }

            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(clubId, contextUser.Id, $"{contextUser.DisplayName} left the club"));
            return true;
        }

        public IEnumerable<Club> GetAll()
        {
            return this._dbContext.Execute<Club>("GetAllClubs", new { userId = this._requestContext.UserId });
        }

        public IEnumerable<Participant> GetAllParticipants(Guid clubId)
        {
            return this._dbContext.Execute<Participant>("GetParticipants", new { clubId });
        }

        public Club GetClub(Guid id)
        {
            return this._mapper.Map<Club>(this._dbContext.GetRecord<Data.Club>(id));
        }

        public IEnumerable<ClubChatListItem> GetClubChatList()
        {
            return this._dbContext.Execute<ClubChatListItem>("GetClubChatListItem", new { userId = this._requestContext.UserId });
        }

        public IEnumerable<ClubMembershipDetails> GetClubMemberships()
        {
            return this._dbContext.Execute<ClubMembershipDetails>("GetClubMemberShips", new { userId = this._requestContext.UserId });
        }

        public IEnumerable<Request> GetClubRequests(Guid clubId)
        {
            return this._dbContext.Execute<Request>("GetClubRequests", new { clubId });
        }

        public IEnumerable<InactiveClub> GetInactiveClubs()
        {
            return this._dbContext.GetAllRecords<Data.InactiveClub>().Select(club => this._mapper.Map<InactiveClub>(club));
        }

        public bool HandleRequest(Guid requestId, RequestStatus status)
        {
            var request = this._dbContext.GetRecord<Data.ClubRequest>(requestId);
            if (status == RequestStatus.Accept)
            {
                var user = this._dbContext.GetRecord<Data.User>(request.UserId);
                this._dbContext.InsertRecord(this.BuildNewUserClubObject(request.ClubId, request.UserId));
                this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(request.ClubId, this._requestContext.UserId, $"{user.DisplayName} joined the club"));
            }

            request.RequestStatus = Convert.ToByte(status);
            request.ActionTakenOn = DateTime.Now;
            request.ActionTakenBy = this._requestContext.UserId;
            request.SetAuditFieldsOnUpdate<Data.ClubRequest>(this._requestContext);
            return this._dbContext.Update(request);
        }

        public bool MakeClubAdmin(Guid clubId, Guid userId)
        {
            var userClub = this._dbContext.Query<Data.UserClub>("SELECT * FROM [dbo].[UserClub] WHERE ClubId = @clubId AND UserId = @userId and IsDeleted = 0", new { clubId, userId });
            if (userClub == null)
            {
                return false;
            }
            var clubAdmin = this._dbContext.Query<Data.ClubAdmin>("SELECT * FROM [dbo].[ClubAdmin] WHERE ClubId = @clubId AND UserId = @userId", new { clubId, userId });
            if (clubAdmin != null)
            {
                clubAdmin.IsDeleted = false;
                this.UpdateAdminDetails(clubAdmin);
            }
            else
            {
                clubAdmin = new Data.ClubAdmin { ClubId = clubId, UserId = userId };
                clubAdmin.SetAuditFieldsOnCreate<Data.ClubAdmin>(this._requestContext);
                this._dbContext.InsertRecord(clubAdmin);
            }
            var user = this._dbContext.GetRecord<Data.User>(userId);
            if (user.Role == Convert.ToByte(Role.User))
            {
                user.Role = Convert.ToByte(Role.ClubAdmin);
            }
            return this._dbContext.Update(user);
        }

        public bool HandleJoinClubRequest(Guid clubId)
        {
            var club = this._dbContext.GetRecord<Data.Club>(clubId);
            if ((VisibilityType)club.Visibility == VisibilityType.Private)
            {
                return false;
            }

            if ((ClubType)club.Type == ClubType.Closed)
            {
                var request = new Data.ClubRequest { UserId = this._requestContext.UserId, ClubId = clubId, ActionTakenBy = this._requestContext.UserId };
                request.SetAuditFieldsOnCreate<Data.ClubRequest>(this._requestContext);
                this._dbContext.InsertRecord(request);
                return true;
            }

            var contextUser = this._dbContext.GetRecord<Data.User>(this._requestContext.UserId);
            this._dbContext.InsertRecord(this.BuildNewUserClubObject(clubId, this._requestContext.UserId));
            this._dbContext.InsertRecord(new Data.ClubChatUpdateLog().BuildLog(clubId, contextUser.Id, $"{contextUser.DisplayName} joined the club"));
            return true;
        }

        public bool RemoveAdmin(Guid clubId, Guid userId)
        {
            if (userId == this._requestContext.UserId)
            {
                return false;
            }

            var clubAdmin = this._dbContext.Query<Data.ClubAdmin>("SELECT * FROM [dbo].[ClubAdmin] WHERE ClubId = @clubId AND UserId = @userId", new { clubId, userId });
            clubAdmin.IsDeleted = true;
            var count = this._dbContext.Query<int>("SELECT COUNT(*) FROM [dbo].[ClubAdmin] WHERE UserId = @userId and IsDeleted = 0", new { userId });
            if (count == 1)
            {
                var user = this._dbContext.GetRecord<Data.User>(userId);
                user.Role = Convert.ToByte(Role.User);
                this._dbContext.Update(user);
            }
            return this.UpdateAdminDetails(clubAdmin);
        }

        public bool ReportClub(Guid clubId)
        {
            if (clubId == Guid.Empty)
            {
                return false;
            }

            var complaintLog = new Data.ComplaintLog() { ClubId = clubId, ReportedBy = this._requestContext.UserId, ReportedOn = DateTime.Now };
            complaintLog.SetAuditFieldsOnCreate<Data.ClubRequest>(this._requestContext);
            this._dbContext.InsertRecord(complaintLog);

            return true;
        }

        public bool ToggleBlockUser(Guid clubId, Guid userId)
        {
            var userClub = this.BuildModifiedUserClubObject(clubId, userId);
            userClub.IsBlocked = !userClub.IsBlocked;
            return this._dbContext.Update(userClub);
        }

        public bool ToggleFavouriteClub(Guid clubId)
        {
            var userClub = this.BuildModifiedUserClubObject(clubId, this._requestContext.UserId);
            userClub.IsFavourite = !userClub.IsFavourite;
            return this._dbContext.Update(userClub);
        }

        public bool ToggleMuteClub(Guid clubId)
        {
            var userClub = this.BuildModifiedUserClubObject(clubId, this._requestContext.UserId);
            userClub.IsMuted = !userClub.IsMuted;
            return this._dbContext.Update(userClub);
        }

        private bool UpdateAdminDetails(Data.ClubAdmin clubAdmin)
        {
            clubAdmin.SetAuditFieldsOnUpdate<Data.ClubAdmin>(this._requestContext);
            return this._dbContext.Update(clubAdmin);
        }

        private Data.UserClub BuildModifiedUserClubObject(Guid clubId, Guid userId)
        {
            var userClub = this._dbContext.Query<Data.UserClub>("SELECT * FROM [dbo].[UserClub] WHERE [UserId] = @userId AND [ClubId] = @clubId", new { userId, clubId });
            userClub.SetAuditFieldsOnUpdate<Data.UserClub>(this._requestContext);
            return userClub;
        }

        private Data.UserClub BuildNewUserClubObject(Guid clubId, Guid userId)
        {
            var userClub = new Data.UserClub() { ClubId = clubId, UserId = userId };
            userClub.SetAuditFieldsOnCreate<Data.UserClub>(this._requestContext);
            return userClub;
        }

        public IEnumerable<ClubNonParticipantsDetails> GetClubNonParticipants(Guid clubId)
        {
            return this._dbContext.Execute<ClubNonParticipantsDetails>("GetClubNonParticipants", new { clubId });
        }
    }
}
