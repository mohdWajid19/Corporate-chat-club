﻿using WebApi.Data.DapperContext;
using WebApi.Models;

namespace WebApi.Services
{
    public class ConnectionService : IConnectionService
    {
        private readonly RequestContext _requestContext;

        private readonly IApplicationDbContext _dbContext;

        public ConnectionService(RequestContext requestContext, IApplicationDbContext dbContext)
        {
            this._requestContext = requestContext;
            this._dbContext = dbContext;
        }

        public bool AddConnection(Guid userId)
        {
            if (userId == Guid.Empty)
            {
                return false;
            }

            var connection = this.GetConnection(this._requestContext.UserId, userId);
            if (connection != null)
            {
                connection = this.GetUpdatedConnection(this._requestContext.UserId, userId);
                connection.IsDeleted = false;
                return this._dbContext.Update(connection);
            }

            this._dbContext.InsertRecord<Data.Connection>(this.GetNewConnection(this._requestContext.UserId, userId));
            this._dbContext.InsertRecord<Data.Connection>(this.GetNewConnection(userId, this._requestContext.UserId));
            return true;
        }

        public IEnumerable<AvailableConnectionDetails> GetAllAvailableNewConnections()
        {
            return this._dbContext.Execute<AvailableConnectionDetails>("GetAvailableConnectionDetails", new { userId = this._requestContext.UserId });
        }

        public IEnumerable<ExistingConnectionDetails> GetAllConnectionDetails()
        {
            return this._dbContext.Execute<ExistingConnectionDetails>("GetUserConnections", new { userId = this._requestContext.UserId });
        }

        public IEnumerable<ThreadListItem> GetAllUserConnections()
        {
            return this._dbContext.Execute<ThreadListItem>("GetUserThreadListItem", new { userId = this._requestContext.UserId });
        }

        public bool RemoveConnection(Guid userId)
        {
            var connection = this.GetUpdatedConnection(this._requestContext.UserId, userId);
            connection.IsDeleted = true;
            this._dbContext.Update(connection);
            connection = this.GetUpdatedConnection(userId, this._requestContext.UserId);
            connection.IsDeleted = true;
            return this._dbContext.Update(connection);
        }

        public bool ToggleBlockConnection(Guid userId)
        {
            var connection = this.GetUpdatedConnection(this._requestContext.UserId, userId);
            connection.IsBlocked = !connection.IsBlocked;
            return this._dbContext.Update(connection);
        }

        public bool ToggleFavourite(Guid userId)
        {
            var connection = this.GetUpdatedConnection(this._requestContext.UserId, userId);
            connection.IsFavourite = !connection.IsFavourite;
            return this._dbContext.Update(connection);
        }

        public bool ToggleMuteConnection(Guid userId)
        {
            var connection = this.GetUpdatedConnection(this._requestContext.UserId, userId);
            connection.IsMuted = !connection.IsMuted;
            return this._dbContext.Update(connection);
        }

        private Data.Connection GetUpdatedConnection(Guid senderId, Guid receiverId)
        {
            var connection = this.GetConnection(senderId, receiverId);
            connection.SetAuditFieldsOnUpdate<Data.Connection>(this._requestContext);
            return connection;
        }

        private Data.Connection GetNewConnection(Guid senderId, Guid receiverId)
        {
            var connection = new Data.Connection() { SenderId = senderId, ReceiverId = receiverId };
            connection.SetAuditFieldsOnCreate<Data.Connection>(this._requestContext);
            return connection;
        }

        private Data.Connection GetConnection(Guid senderId, Guid receiverId)
        {
            return this._dbContext.Query<Data.Connection>("SELECT * FROM [dbo].[Connection] WHERE [SenderId] = @senderId AND [ReceiverId] = @receiverId", new { senderId, receiverId });
        }
    }
}
