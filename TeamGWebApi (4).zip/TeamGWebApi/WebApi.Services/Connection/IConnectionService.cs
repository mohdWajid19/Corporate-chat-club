﻿using WebApi.Models;

namespace WebApi.Services
{
    public interface IConnectionService
    {
        public IEnumerable<ThreadListItem> GetAllUserConnections();

        public IEnumerable<AvailableConnectionDetails> GetAllAvailableNewConnections();

        public IEnumerable<ExistingConnectionDetails> GetAllConnectionDetails();

        public bool AddConnection(Guid userId);

        public bool RemoveConnection(Guid userId);

        public bool ToggleBlockConnection(Guid userId);

        public bool ToggleMuteConnection(Guid userId);

        public bool ToggleFavourite(Guid userId);
    }
}
