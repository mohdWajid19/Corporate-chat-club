﻿CREATE TABLE [dbo].[User]
(
	[Id]                UNIQUEIDENTIFIER    NOT NULL    PRIMARY KEY DEFAULT NEWSEQUENTIALID(), 
    [FirstName]         VARCHAR(50)         NOT NULL, 
    [MiddleName]        VARCHAR(50)         NULL, 
    [LastName]          VARCHAR(50)         NOT NULL, 
    [DisplayName]       VARCHAR(150)        NOT NULL, 
    [Phone]             VARCHAR(20)         NOT NULL, 
    [Email]             VARCHAR(50)         NOT NULL, 
    [Status]            TINYINT             NOT NULL    CONSTRAINT[DF_User_Status] DEFAULT 0, 
    [ActionTakenBy]     UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [User](Id),
    [ActionTakenOn]		DATETIME			NULL,
    [Reason]            VARCHAR(100)        NULL, 
    [IsDeleted]         BIT                 NOT NULL    CONSTRAINT[DF_User_IsDeleted] DEFAULT 0,
    [AddedBy]           UNIQUEIDENTIFIER    NOT NULL, 
    [AddedOn]           DATETIME            NOT NULL,
    [Role]              TINYINT             NOT NULL    CONSTRAINT[DF_User_Role] DEFAULT 0, 
    [CreatedBy]         UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]       DATETIME            NOT NULL, 
    [ModifiedBy]        UNIQUEIDENTIFIER    NULL, 
    [DateModified]      DATETIME            NULL
)

GO

CREATE TABLE [dbo].[UserProfile]
(
    [Id]                    UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[UserId]                UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [ProfileImageUrl]       NVARCHAR(MAX)       NULL, 
    [Gender]                TINYINT             NULL        CONSTRAINT[DF_UserProfile_Gender] DEFAULT 0, 
    [DOB]                   DATE                NULL, 
    [BloodGroup]            TINYINT             NULL        CONSTRAINT[DF_UserProfile_BloodGroup] DEFAULT 0, 
    [MaritalStatus]         TINYINT             NULL        CONSTRAINT[DF_UserProfile_MaritalStatus] DEFAULT 0, 
    [About]                 VARCHAR(400)        NULL, 
    [Address]               VARCHAR(400)        NULL, 
    [ProfessionalSummary]   VARCHAR(400)        NULL, 
    [CreatedBy]             UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]           DATETIME            NOT NULL, 
    [ModifiedBy]            UNIQUEIDENTIFIER    NULL, 
    [DateModified]          DATETIME            NULL
)

GO

CREATE TABLE [dbo].[Club]
(
	[IconUrl]			NVARCHAR(MAX)		NULL,
	[Id]				UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[Title]				VARCHAR(100)		NOT NULL,
	[OwnerId]			UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
	[Visibility]		BIT					NOT NULL,
	[Type]				BIT					NULL,
	[Description]		VARCHAR(200)		NOT NULL,
	[CreatedOn]			DATETIME			NOT NULL,
	[Status]			TINYINT				NOT NULL	CONSTRAINT[DF_Club_Status] DEFAULT 0,
	[ActionTakenBy]     UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [User](Id),
	[ActionTakenOn]		DATETIME			NULL,
	[Reason]			NVARCHAR(MAX)		NULL,
	[IsMuted]			BIT					NOT NULL	CONSTRAINT[DF_Club_IsMuted]	DEFAULT 0,
	[IsDeleted]			BIT					NOT NULL	CONSTRAINT[DF_Club_IsDeleted] DEFAULT 0,
	[CreatedBy]			UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]		DATETIME			NOT NULL,
	[ModifiedBy]		UNIQUEIDENTIFIER	NULL,
	[DateModified]		DATETIME			NULL
)

GO

CREATE TABLE [dbo].[Message]
(
	[Id]            UNIQUEIDENTIFIER    NOT NULL    PRIMARY KEY DEFAULT NEWSEQUENTIALID(), 
    [Body]          NVARCHAR(MAX)       NULL,
    [TimeStamp]     DATETIME            NOT NULL, 
    [ClubId]        UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [Club](Id),
    [SenderId]      UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id),
    [ReceiverId]    UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [User](Id),
    [Status]        TINYINT             NOT NULL    CONSTRAINT[DF_Message_Status] DEFAULT 0,
    [Attachments]   NVARCHAR(MAX)       NULL, 
    [CreatedBy]     UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]   DATETIME            NOT NULL, 
    [ModifiedBy]    UNIQUEIDENTIFIER    NULL, 
    [DateModified]  DATETIME            NULL
)

GO

CREATE TABLE [dbo].[ComplaintLog]
(
	[Id]				UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[ReportedBy]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
	[ClubId]			UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [Club](Id),
	[ReportedOn]		DATETIME			NOT NULL,
	[CreatedBy]			UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]		DATETIME			NOT NULL,
	[ModifiedBy]		UNIQUEIDENTIFIER	NULL,
	[DateModified]		DATETIME			NULL
)

GO

CREATE TABLE [dbo].[ClubChatUpdateLog]
(
	[Id]			UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[ClubId]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [Club](Id), 
    [UpdateBy]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
    [Message]		NVARCHAR(MAX)		NOT NULL, 
    [TimeStamp]		DATETIME			NOT NULL,
    [CreatedBy]		UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]	DATETIME			NOT NULL,
	[ModifiedBy]	UNIQUEIDENTIFIER	NULL,
	[DateModified]	DATETIME			NULL
)

GO

CREATE TABLE [dbo].[Connection]
(
    [Id]            UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[SenderId]      UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [ReceiverId]    UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [IsFavourite]   BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsFavourite] DEFAULT 0, 
    [IsBlocked]     BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsBlocked] DEFAULT 0,
    [IsDeleted]     BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsDeleted] DEFAULT 0, 
    [IsMuted]       BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsMuted] DEFAULT 0,
    [CreatedBy]     UNIQUEIDENTIFIER    NOT NULL,
	[DateCreated]   DATETIME            NOT NULL,
	[ModifiedBy]    UNIQUEIDENTIFIER    NULL,
	[DateModified]  DATETIME            NULL
)

GO

CREATE TABLE [dbo].[UserClub]
(
	[Id]			UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[ClubId]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [Club](Id),
	[UserId]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
	[IsFavourite]	BIT					NOT NULL	CONSTRAINT[DF_UserClub_IsFavourite] DEFAULT 0,
	[IsBlocked]		BIT					NOT NULL	CONSTRAINT[DF_UserClub_IsBlocked] DEFAULT 0,
	[IsMuted]		BIT					NOT NULL	CONSTRAINT[DF_UserClub_IsMuted] DEFAULT 0,
	[IsDeleted]		BIT					NOT NULL	CONSTRAINT[DF_UserClub_IsDeleted] DEFAULT 0,
	[CreatedBy]		UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]	DATETIME			NOT NULL,
	[ModifiedBy]	UNIQUEIDENTIFIER	NULL,
	[DateModified]	DATETIME			NULL
)

GO

CREATE TABLE [dbo].[ClubAdmin]
(
	[Id]			UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[ClubId]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [Club](Id),
    [UserId]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
    [IsDeleted]		BIT					NOT NULL	CONSTRAINT[DF_ClubAdmin_IsDeleted] DEFAULT 0,
    [CreatedBy]		UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]	DATETIME			NOT NULL,
	[ModifiedBy]	UNIQUEIDENTIFIER	NULL,		
	[DateModified]	DATETIME			NULL,
)

GO

CREATE TABLE [dbo].[ClubRequest]
(
	[Id]				UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[ClubId]			UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [Club](Id),
	[UserId]			UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
	[ActionTakenBy]		UNIQUEIDENTIFIER	NOT NULL	FOREIGN KEY REFERENCES [User](Id),
	[RequestStatus]		TINYINT				NOT NULL	CONSTRAINT[DF_ClubRequest_RequestStatus] DEFAULT 0,
	[ActionTakenOn]		DATETIME			NULL,
	[CreatedBy]			UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]		DATETIME			NOT NULL,
	[ModifiedBy]		UNIQUEIDENTIFIER	NULL,
	[DateModified]		DATETIME			NULL
)

GO

CREATE TABLE [dbo].[UserLogin]
(
	[Id]			UNIQUEIDENTIFIER	NOT NULL PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[UserName]		VARCHAR(50)			NOT NULL,
	[PasswordHash]	VARBINARY(MAX)		NOT NULL,
	[PasswordSalt]	VARBINARY(MAX)		NOT NULL,
	[IsDeleted]		BIT					NOT NULL CONSTRAINT[DF_UserLogin_IsDeleted] DEFAULT 0,
	[CreatedBy]		UNIQUEIDENTIFIER	NOT NULL,
	[DateCreated]	DATETIME			NOT NULL,
	[ModifiedBy]	UNIQUEIDENTIFIER	NULL,
	[DateModified]	DATETIME			NULL
)