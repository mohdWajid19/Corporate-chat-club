﻿CREATE TABLE [dbo].[Message]
(
	[Id]            UNIQUEIDENTIFIER    NOT NULL    PRIMARY KEY DEFAULT NEWSEQUENTIALID(), 
    [Body]          NVARCHAR(MAX)       NULL,
    [TimeStamp]     DATETIME            NOT NULL, 
    [ClubId]        UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [Club](Id),
    [SenderId]      UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id),
    [ReceiverId]    UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [User](Id),
    [Status]        TINYINT             NOT NULL    CONSTRAINT[DF_Message_Status] DEFAULT 0,
    [Attachments]   NVARCHAR(MAX)       NULL, 
    [CreatedBy]     UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]   DATETIME            NOT NULL, 
    [ModifiedBy]    UNIQUEIDENTIFIER    NULL, 
    [DateModified]  DATETIME            NULL
)