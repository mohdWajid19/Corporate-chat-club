﻿CREATE TABLE [dbo].[Connection]
(
    [Id]            UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[SenderId]      UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [ReceiverId]    UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [IsFavourite]   BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsFavourite] DEFAULT 0, 
    [IsBlocked]     BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsBlocked] DEFAULT 0,
    [IsDeleted]     BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsDeleted] DEFAULT 0, 
    [IsMuted]       BIT                 NOT NULL    CONSTRAINT[DF_Connection_IsMuted] DEFAULT 0,
    [CreatedBy]     UNIQUEIDENTIFIER    NOT NULL,
	[DateCreated]   DATETIME            NOT NULL,
	[ModifiedBy]    UNIQUEIDENTIFIER    NULL,
	[DateModified]  DATETIME            NULL
)