﻿CREATE TABLE [dbo].[User]
(
	[Id]                UNIQUEIDENTIFIER    NOT NULL    PRIMARY KEY DEFAULT NEWSEQUENTIALID(), 
    [FirstName]         VARCHAR(50)         NOT NULL, 
    [MiddleName]        VARCHAR(50)         NULL, 
    [LastName]          VARCHAR(50)         NOT NULL, 
    [DisplayName]       VARCHAR(150)        NOT NULL, 
    [Phone]             VARCHAR(20)         NOT NULL, 
    [Email]             VARCHAR(50)         NOT NULL, 
    [Status]            TINYINT             NOT NULL    CONSTRAINT[DF_User_Status] DEFAULT 0, 
    [ActionTakenBy]     UNIQUEIDENTIFIER    NULL        FOREIGN KEY REFERENCES [User](Id),
    [ActionTakenOn]		DATETIME			NULL,
    [Reason]            VARCHAR(100)        NULL, 
    [IsDeleted]         BIT                 NOT NULL    CONSTRAINT[DF_User_IsDeleted] DEFAULT 0,
    [AddedBy]           UNIQUEIDENTIFIER    NOT NULL, 
    [AddedOn]           DATETIME            NOT NULL,
    [Role]              TINYINT             NOT NULL    CONSTRAINT[DF_User_Role] DEFAULT 0, 
    [CreatedBy]         UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]       DATETIME            NOT NULL, 
    [ModifiedBy]        UNIQUEIDENTIFIER    NULL, 
    [DateModified]      DATETIME            NULL
)