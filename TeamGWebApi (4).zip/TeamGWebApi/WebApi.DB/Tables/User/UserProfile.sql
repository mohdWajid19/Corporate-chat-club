﻿CREATE TABLE [dbo].[UserProfile]
(
    [Id]                    UNIQUEIDENTIFIER	NOT NULL	PRIMARY KEY DEFAULT NEWSEQUENTIALID(),
	[UserId]                UNIQUEIDENTIFIER    NOT NULL    FOREIGN KEY REFERENCES [User](Id), 
    [ProfileImageUrl]       NVARCHAR(MAX)       NULL, 
    [Gender]                TINYINT             NULL        CONSTRAINT[DF_UserProfile_Gender] DEFAULT 0, 
    [DOB]                   DATE                NULL, 
    [BloodGroup]            TINYINT             NULL        CONSTRAINT[DF_UserProfile_BloodGroup] DEFAULT 0, 
    [MaritalStatus]         TINYINT             NULL        CONSTRAINT[DF_UserProfile_MaritalStatus] DEFAULT 0, 
    [About]                 VARCHAR(400)        NULL, 
    [Address]               VARCHAR(400)        NULL, 
    [ProfessionalSummary]   VARCHAR(400)        NULL, 
    [CreatedBy]             UNIQUEIDENTIFIER    NOT NULL, 
    [DateCreated]           DATETIME            NOT NULL, 
    [ModifiedBy]            UNIQUEIDENTIFIER    NULL, 
    [DateModified]          DATETIME            NULL
)