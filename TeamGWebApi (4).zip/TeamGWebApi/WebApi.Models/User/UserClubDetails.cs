﻿namespace WebApi.Models
{
    public class UserClubDetails : User
    {
        public string AddedByUserName { get; set; }

        public int ActiveClubsCount { get; set; }
    }
}
