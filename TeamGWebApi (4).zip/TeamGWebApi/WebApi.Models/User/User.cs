﻿namespace WebApi.Models
{
    public class User
    {
        public Guid Id { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string DisplayName { get; set; }

        public string Phone { get; set; }

        public string Email { get; set; }

        public UserStatus Status { get; set; }

        public Guid ActionTakenBy { get; set; }

        public DateTime ActionTakenOn { get; set; }

        public string Reason { get; set; }

        public bool IsDeleted { get; set; }

        public Guid AddedBy { get; set; }

        public DateTime AddedOn { get; set; }

        public Role Role { get; set; }
    }
}
