﻿namespace WebApi.Models
{
    public class UserDetails : User
    {
        public string ProfileImageUrl { get; set; }

        public Gender Gender { get; set; }

        public DateTime DOB { get; set; }

        public BloodGroup BloodGroup { get; set; }

        public MaritalStatus MaritalStatus { get; set; }

        public string About { get; set; }

        public string Address { get; set; }

        public string ProfessionalSummary { get; set; }
    }
}