﻿namespace WebApi.Models
{
    public class Request: BaseUserListItem
    {
        
    }
}
