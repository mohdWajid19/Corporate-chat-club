﻿namespace WebApi.Models
{
    public class AvailableConnectionDetails : ConnectionDetails
    {
        public int MutualUsersCount { get; set; }
    }
}
