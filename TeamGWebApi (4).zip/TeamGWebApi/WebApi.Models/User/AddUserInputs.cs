﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models
{
    public class AddUserInputs
    {
        [Required(ErrorMessage = "FirstName is required")]
        public string FirstName { get; set; }

        public string? MiddleName { get; set; }

        public string LastName { get; set; }

        [Required(ErrorMessage = "DisplayName is required")]
        public string DisplayName { get; set; }

        [Required]
        [RegularExpression("(^\\d{10}$)",ErrorMessage ="Phone is invalid")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage ="Email is invalid")]
        public string Email { get; set; }

        public UserStatus Status { get; set; }

        public List<Guid>? TaggedClubs { get; set; }
    }
}
