﻿namespace WebApi.Models
{
    public class ExistingConnectionDetails: ConnectionDetails
    {
        public string Description { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }
    }
}
