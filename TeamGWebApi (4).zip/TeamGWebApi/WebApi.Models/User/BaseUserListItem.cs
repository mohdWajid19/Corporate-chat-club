﻿namespace WebApi.Models
{
    public  class BaseUserListItem
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string ProfileImageUrl { get; set; }

        public string Email { get; set; }
    }
}
