﻿namespace WebApi.Models
{
    public class Participant : BaseUserListItem
    {
        public UserStatus Status { get; set; }

        public Role Role { get; set; }

        public bool IsBlocked { get; set; }
    }
}
