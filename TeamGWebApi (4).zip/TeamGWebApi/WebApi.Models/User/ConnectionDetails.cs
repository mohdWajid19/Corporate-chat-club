﻿namespace WebApi.Models
{
    public class ConnectionDetails
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string ProfileImageUrl { get; set; }

        public int MutualClubsCount { get; set; }
    }
}
