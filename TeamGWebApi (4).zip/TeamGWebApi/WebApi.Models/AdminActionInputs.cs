﻿namespace WebApi.Models
{
    public class AdminActionInputs
    {
        public Guid Id { get; set; }

        public string Reason { get; set; }
    }
}
