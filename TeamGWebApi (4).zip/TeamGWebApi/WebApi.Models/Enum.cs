﻿namespace WebApi.Models
{
    public enum UserStatus
    {
        Active,
        Inactive, 
        Invited,
        NotInvited
    };

    public enum ClubStatus
    {
        Active,
        Inactive
    };

    public enum ClubType
    {
        Open,
        Closed
    }

    public enum Role
    {
        GlobalAdmin,
        ClubAdmin,
        User
    };

    public enum VisibilityType
    {
        Public,
        Private
    };

    public enum RequestStatus
    {
        Hold,
        Accept,
        Decline
    };

    public enum Gender
    {
        NotSpecify,
        Male,
        Female
    };

    public enum MessageStatus
    {
        Sent,
        NotSeen,
        Seen
    };
    public enum BloodGroup
    {
        OPositive,
        ONegative,
        APositive,
        ANegative,
        BPositive,
        BNegative,
        ABPositive,
        ABNegative
    };

    public enum MaritalStatus
    {
        Single,
        Married,
        Widow,
        Widower,
        Divorced
    };
}
