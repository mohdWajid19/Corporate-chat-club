﻿namespace WebApi.Models
{
    public class ClubChatListItem : ChatListItem
    {
        public string Title { get; set; }

        public string IconUrl { get; set; }
    }
}
