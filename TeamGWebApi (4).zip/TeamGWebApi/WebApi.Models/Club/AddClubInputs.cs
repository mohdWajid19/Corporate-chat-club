﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models
{
    public class AddClubInputs
    {
        public string? IconUrl { get; set; }

        [Required(ErrorMessage ="Title is required")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        public VisibilityType Visibility { get; set; }

        public ClubType Type { get; set; }

        public List<Guid>? Admins { get; set; }

        [Required(ErrorMessage = "Participants is required")]
        public List<Guid>? Participants { get; set; }
    }
}