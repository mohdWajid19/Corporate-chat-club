﻿namespace WebApi.Models
{
    public class Club
    {
        public Guid Id { get; set; }

        public string IconUrl { get; set; }

        public string Title { get; set; }

        public Guid OwnerId { get; set; }

        public VisibilityType Visibility { get; set; }

        public ClubType Type { get; set; }

        public string Description { get; set; }

        public DateTime CreatedOn { get; set; }

        public ClubStatus Status { get; set; }

        public Guid ActionTakenBy { get; set; }

        public DateTime ActionTakenOn { get; set; }

        public string Reason { get; set; }

        public bool IsMuted { get; set; }

        public bool IsDeleted { get; set; }
    }
}
