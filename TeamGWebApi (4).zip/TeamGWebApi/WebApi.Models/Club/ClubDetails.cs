﻿namespace WebApi.Models
{
    public class ClubDetails : Club
    {
        public string CreatedBy { get; set; }

        public bool IsUserMuted { get; set; }
    }
}
