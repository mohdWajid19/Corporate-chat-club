﻿namespace WebApi.Models
{
    public class ClubChat
    {
        public List<Message> Messages { get; set; }

        public List<ChatUpdateLog> ChatUpdateLogs { get; set; }
    }
}
