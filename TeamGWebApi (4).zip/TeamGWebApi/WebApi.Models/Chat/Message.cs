﻿namespace WebApi.Models
{
    public class Message
    {
        public Guid Id { get; set; }

        public string Body { get; set; }

        public DateTime TimeStamp { get; set; }

        public Guid? ClubId { get; set; }

        public Guid SenderId { get; set; }

        public Guid ReceiverId { get; set; }

        public MessageStatus Status { get; set; }

        public List<Attachment>? Attachments { get; set; }
    }
}
