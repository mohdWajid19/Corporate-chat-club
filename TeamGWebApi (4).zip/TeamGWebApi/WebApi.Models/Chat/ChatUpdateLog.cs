﻿namespace WebApi.Models
{
    public class ChatUpdateLog
    {
        public Guid Id { get; set; }

        public Guid ClubId { get; set; }

        public Guid UpdatedBy { get; set; }

        public string Message { get; set; }

        public DateTime TimeStamp { get; set; }
    }
}