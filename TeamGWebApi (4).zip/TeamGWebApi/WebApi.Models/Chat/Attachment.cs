﻿namespace WebApi.Models
{
    public class Attachment
    {
        public string FileName { get; set; }

        public string FileDataUrl { get; set; }
    }
}
