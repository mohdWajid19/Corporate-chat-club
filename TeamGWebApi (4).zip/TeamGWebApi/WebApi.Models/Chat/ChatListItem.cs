﻿namespace WebApi.Models
{
    public class ChatListItem : Message
    {
        public bool IsFavourite { get; set; }

        public int UnReadMessageCount { get; set; }

        public bool IsMuted { get; set; }
    }
}