﻿namespace WebApi.Models
{
    public class ChangePasswordInput
    {
        public string UserName { get; set; }

        public string OldPassword { get; set; }

        public string NewPassword { get; set; }
    }
}
