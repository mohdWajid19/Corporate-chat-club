import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HeaderComponent } from './header';
import { LeftNavComponent } from './left-nav';

@NgModule({
  declarations: [
    HeaderComponent,
    LeftNavComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    HeaderComponent,
    LeftNavComponent
  ]
})

export class LayoutModule { }
