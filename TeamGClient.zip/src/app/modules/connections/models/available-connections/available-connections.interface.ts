export interface AvailableConnections {
  id : string;
  name : string;
  profileImageUrl : string;
  mutualClubsCount : number;
  mutualUsersCount : number;
}