export interface UserConnections {
  id : string;
  name : string;
  profileImageUrl : string;
  mutualClubsCount : number;
  description : string;
  email : string;
  phone : string;
}