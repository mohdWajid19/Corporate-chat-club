import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConnectionsRoutingModule } from './connections-routing.module';
import { MyConnectionsComponent } from './components';
import { ConnectionsComponent } from './pages';

@NgModule({
  declarations: [
    ConnectionsComponent,
    MyConnectionsComponent
  ],
  imports: [
    CommonModule,
    ConnectionsRoutingModule
  ]
})

export class ConnectionsModule { }
