import { Component } from '@angular/core';

@Component({
  selector: 'app-my-connections',
  templateUrl: './my-connections.component.html'
})

export class MyConnectionsComponent {

}
