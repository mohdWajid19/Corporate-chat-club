import { Component } from '@angular/core';

@Component({
  selector: 'app-clubs',
  templateUrl: './clubs.component.html'
})

export class ClubsComponent {

}
