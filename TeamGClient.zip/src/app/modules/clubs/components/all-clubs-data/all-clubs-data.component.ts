import { Component } from '@angular/core';

@Component({
  selector: 'app-all-clubs-data',
  templateUrl: './all-clubs-data.component.html'
})

export class AllClubsDataComponent {

}
