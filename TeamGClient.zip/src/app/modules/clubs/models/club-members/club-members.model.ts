export class ClubMembers {
  id : string;
  displayName : string;

  constructor(args : ClubMembers) {
    this.id = args.id;
    this.displayName = args.displayName;
  }
}