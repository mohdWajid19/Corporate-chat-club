export enum RequestStatus {
  Decline = 0,
  Accept = 1,
  Hold = 2 
}