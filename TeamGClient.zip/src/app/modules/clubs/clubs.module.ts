import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClubsRoutingModule } from './clubs-routing.module';
import { AllClubsDataComponent } from './components';
import { ClubsComponent } from './pages';

@NgModule({
  declarations: [
    AllClubsDataComponent,
    ClubsComponent
  ],
  imports: [
    CommonModule,
    ClubsRoutingModule
  ]
})

export class ClubsModule { }
