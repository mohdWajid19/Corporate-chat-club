import { Component } from '@angular/core';

@Component({
  selector: 'app-corporate-chat-club',
  templateUrl: './corporate-chat-club.component.html'
})

export class CorporateChatClubComponent {

}
