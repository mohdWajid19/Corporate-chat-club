import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CorporateChatClubRoutingModule } from './corporate-chat-club-routing.module';
import { CorporateChatClubComponent } from './pages';

@NgModule({
  declarations: [
    CorporateChatClubComponent
  ],
  imports: [
    CommonModule,
    CorporateChatClubRoutingModule
  ]
})

export class CorporateChatClubModule { }
