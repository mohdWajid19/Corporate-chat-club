import { Component } from '@angular/core';

@Component({
  selector: 'app-inactive-clubs',
  templateUrl: './inactive-clubs.component.html'
})

export class InactiveClubsComponent {

}
