import { Component } from '@angular/core';

@Component({
  selector: 'app-inactive-clubs-data',
  templateUrl: './inactive-clubs-data.component.html'
})

export class InactiveClubsDataComponent {

}
