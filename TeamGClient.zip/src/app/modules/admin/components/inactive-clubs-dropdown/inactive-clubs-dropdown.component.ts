import { Component } from '@angular/core';

@Component({
  selector: 'app-inactive-clubs-dropdown',
  templateUrl: './inactive-clubs-dropdown.component.html'
})

export class InactiveClubsDropdownComponent {

}
