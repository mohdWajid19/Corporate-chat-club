import { Component } from '@angular/core';

@Component({
  selector: 'app-users-data',
  templateUrl: './users-data.component.html'
})

export class UsersDataComponent {

}
