import { Component } from '@angular/core';

@Component({
  selector: 'app-users-dropdown',
  templateUrl: './users-dropdown.component.html'
})

export class UsersDropdownComponent {

}
