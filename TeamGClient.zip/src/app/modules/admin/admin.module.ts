import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { InactiveClubsDataComponent, InactiveClubsDropdownComponent, UsersDataComponent, UsersDropdownComponent } from './components';
import { AdminComponent, InactiveClubsComponent, UsersComponent } from './pages';

@NgModule({
  declarations: [
    UsersDataComponent,
    InactiveClubsDataComponent,
    InactiveClubsDropdownComponent,
    UsersDropdownComponent,
    UsersComponent,
    InactiveClubsComponent,
    AdminComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ]
})

export class AdminModule { }
