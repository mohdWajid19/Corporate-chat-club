export class ClubMembership {
  id: string;
  title: string;
  iconUrl: string;

  constructor(args : ClubMembership) {
    this.id = args.id;
    this.title = args.title;
    this.iconUrl = args.iconUrl;
  }

}