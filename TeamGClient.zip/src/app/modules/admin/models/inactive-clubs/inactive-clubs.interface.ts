import { ClubDetails } from "src/app/shared/models";

export interface InactiveClubs extends ClubDetails {
  createdByName : string;
  deactivatedByName : string;
}