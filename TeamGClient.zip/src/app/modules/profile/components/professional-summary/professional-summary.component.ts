import { Component } from '@angular/core';

@Component({
  selector: 'app-professional-summary',
  templateUrl: './professional-summary.component.html'
})

export class ProfessionalSummaryComponent {

}
