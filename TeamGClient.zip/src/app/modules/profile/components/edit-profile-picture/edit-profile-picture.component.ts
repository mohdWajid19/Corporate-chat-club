import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-profile-picture',
  templateUrl: './edit-profile-picture.component.html'
})

export class EditProfilePictureComponent {

}
