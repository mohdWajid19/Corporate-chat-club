import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-professional-summary',
  templateUrl: './edit-professional-summary.component.html'
})

export class EditProfessionalSummaryComponent {

}
