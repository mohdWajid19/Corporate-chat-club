import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-contact-details',
  templateUrl: './edit-contact-details.component.html'
})

export class EditContactDetailsComponent {

}
