import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-personal-details',
  templateUrl: './edit-personal-details.component.html'
})

export class EditPersonalDetailsComponent {

}
