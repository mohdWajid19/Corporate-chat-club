import { BloodGroup, Gender, MaritalStatus, UserDetails } from "src/app/shared/models";

export interface UserProfileDetails extends UserDetails {
  profileImageUrl : string;
  gender : Gender;
  dob : Date;
  bloodGroup : BloodGroup;
  maritalStatus : MaritalStatus;
  about : string;
  professionalSummary : string;
}