import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './pages';
import { ContactDetailsComponent, EditContactDetailsComponent, EditPersonalDetailsComponent, EditProfessionalSummaryComponent, EditProfilePictureComponent, PersonalDetailsComponent, ProfessionalSummaryComponent, ProfileHeaderComponent } from './components';

@NgModule({
  declarations: [
    ProfileComponent,
    ProfileHeaderComponent,
    PersonalDetailsComponent,
    ContactDetailsComponent,
    ProfessionalSummaryComponent,
    EditProfilePictureComponent,
    EditPersonalDetailsComponent,
    EditContactDetailsComponent,
    EditProfessionalSummaryComponent
  ],
  imports: [
    CommonModule,
    ProfileRoutingModule
  ]
})

export class ProfileModule { }
