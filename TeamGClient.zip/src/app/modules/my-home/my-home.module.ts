import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyHomeRoutingModule } from './my-home-routing.module';
import { MyClubsComponent, MyHomeComponent, MyThreadsComponent } from './pages';
import { ClubParticipantsComponent, ClubRequestsComponent, GroupInfoComponent, GroupSettingsComponent, MyClubChatComponent, MyClubsListComponent, MyThreadChatComponent, MyThreadsListComponent } from './components';

@NgModule({
  declarations: [
    MyHomeComponent,
    MyClubsComponent,
    MyThreadsComponent,
    MyClubsListComponent,
    MyClubChatComponent,
    GroupInfoComponent,
    ClubParticipantsComponent,
    ClubRequestsComponent,
    MyThreadsListComponent,
    MyThreadChatComponent,
    GroupSettingsComponent
  ],
  imports: [
    CommonModule,
    MyHomeRoutingModule
  ]
})

export class MyHomeModule { }
