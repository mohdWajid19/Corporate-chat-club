import { Component } from '@angular/core';

@Component({
  selector: 'app-my-threads',
  templateUrl: './my-threads.component.html'
})

export class MyThreadsComponent {

}
