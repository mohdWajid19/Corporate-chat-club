import { Component } from '@angular/core';

@Component({
  selector: 'app-my-clubs',
  templateUrl: './my-clubs.component.html'
})

export class MyClubsComponent {

}
