import { Component } from '@angular/core';

@Component({
  selector: 'app-club-participants',
  templateUrl: './club-participants.component.html'
})

export class ClubParticipantsComponent {

}
