import { Component } from '@angular/core';

@Component({
  selector: 'app-group-settings',
  templateUrl: './group-settings.component.html'
})

export class GroupSettingsComponent {

}
