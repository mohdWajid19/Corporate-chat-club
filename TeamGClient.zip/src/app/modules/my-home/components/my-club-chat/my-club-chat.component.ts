import { Component } from '@angular/core';

@Component({
  selector: 'app-my-club-chat',
  templateUrl: './my-club-chat.component.html'
})

export class MyClubChatComponent {

}
