import { Component } from '@angular/core';

@Component({
  selector: 'app-my-thread-chat',
  templateUrl: './my-thread-chat.component.html'
})

export class MyThreadChatComponent {

}
