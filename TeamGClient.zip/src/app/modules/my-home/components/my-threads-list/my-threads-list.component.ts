import { Component } from '@angular/core';

@Component({
  selector: 'app-my-threads-list',
  templateUrl: './my-threads-list.component.html'
})

export class MyThreadsListComponent {

}
