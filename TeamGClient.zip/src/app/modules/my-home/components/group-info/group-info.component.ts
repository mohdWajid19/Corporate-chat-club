import { Component } from '@angular/core';

@Component({
  selector: 'app-group-info',
  templateUrl: './group-info.component.html'
})

export class GroupInfoComponent {

}
