import { Component } from '@angular/core';

@Component({
  selector: 'app-my-clubs-list',
  templateUrl: './my-clubs-list.component.html'
})

export class MyClubsListComponent {

}
