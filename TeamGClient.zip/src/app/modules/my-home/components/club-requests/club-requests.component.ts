import { Component } from '@angular/core';

@Component({
  selector: 'app-club-requests',
  templateUrl: './club-requests.component.html'
})

export class ClubRequestsComponent {

}
