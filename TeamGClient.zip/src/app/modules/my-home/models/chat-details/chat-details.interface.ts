import { Attachments } from "../attachments";
import { MessageStatus } from "../message-status";

export interface ChatDetails {
  id : string;
  body : string;
  timStamp : Date;
  clubId : string;
  senderId : string;
  receiverId : string;
  status : MessageStatus;
  attachments : Array<Attachments>
}