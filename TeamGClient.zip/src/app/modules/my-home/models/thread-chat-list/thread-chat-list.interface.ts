import { ChatList } from "../chat-list";

export interface ThreadChatList extends ChatList {
  userId : string;
  userName : string;
  profileImageUrl : string;
}