export interface Attachments {
  fileName : string;
  fileDataUrl : string;
}