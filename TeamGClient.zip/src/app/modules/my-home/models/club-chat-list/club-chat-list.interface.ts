import { ChatList } from "../chat-list";

export interface ClubChatList extends ChatList {
  title : string;
  iconUrl : string;
}