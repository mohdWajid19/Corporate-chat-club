export interface ChatUpdateLogs {
  id : string;
  clubId : string;
  updatedBy : string;
  message : string;
  timeStamp : Date;
}