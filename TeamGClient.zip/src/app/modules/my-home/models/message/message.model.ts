import { Attachments } from "../attachments";
import { MessageStatus } from "../message-status";

export class Message {
  id : string;
  body : string;
  timeStamp : Date;
  clubId : string;
  senderId : string;
  receiverId : string;
  status : MessageStatus;
  attachments : Array<Attachments>;

  constructor(args : Message){
    this.id = args.id;
    this.body = args.body;
    this.timeStamp = args.timeStamp;
    this.clubId = args.clubId;
    this.senderId = args.senderId;
    this.receiverId = args.receiverId;
    this.status = args.status;
    this.attachments = args.attachments;
  }
}