import { UserRole, UserStatus } from "src/app/shared/models";
import { ClubRequests } from "../club-requests";

export interface ClubParticipants extends ClubRequests {
  status : UserStatus;
  role : UserRole;
  isBlocked : boolean;
}