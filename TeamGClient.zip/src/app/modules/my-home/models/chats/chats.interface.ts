import { ChatDetails } from "../chat-details";
import { ChatUpdateLogs } from "../chat-update-logs";

export interface Chats {
  messages : Array<ChatDetails>;
  chatUpdateLogs : Array<ChatUpdateLogs>
}