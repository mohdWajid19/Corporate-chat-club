export enum MessageStatus {
  Sent = 0,
  Delivered = 1,
  Seen = 2
}