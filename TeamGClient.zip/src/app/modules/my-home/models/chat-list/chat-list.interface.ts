import { ChatDetails } from "../chat-details";

export interface ChatList extends ChatDetails {
  isFavourite : boolean;
  unReadMessageCount : number;
  isMuted : boolean;
}