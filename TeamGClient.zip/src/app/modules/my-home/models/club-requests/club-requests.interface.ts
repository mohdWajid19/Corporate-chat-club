export interface ClubRequests {
  id : string;
  name : string;
  profileImageUrl : string;
  email : string;
}