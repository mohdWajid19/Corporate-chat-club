export enum UserStatus {
    Active = 0,
    Inactive = 1,
    Invited = 2,
    NotInvited = 3
}