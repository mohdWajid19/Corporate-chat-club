export class UserLoginDetails {
  userName : string;
  password : string;

  constructor(args : UserLoginDetails) {
    this.userName = args.userName;
    this.password = args.password;
  }
}