import { UserDetails } from "src/app/shared/models";

export interface Users extends UserDetails {
  addedByUserName : string;
  activeClubsCount : number;
}