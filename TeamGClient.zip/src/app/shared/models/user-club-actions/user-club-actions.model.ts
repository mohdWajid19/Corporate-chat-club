export class UserClubActions {
  id : string;
  reason : string;

  constructor(args : UserClubActions) {
    this.id = args.id;
    this.reason = args.reason;
  }
}