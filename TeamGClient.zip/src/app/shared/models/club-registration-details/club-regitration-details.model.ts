import { ClubType } from "../club-type";
import { VisibilityType } from "../visibility-type";

export class ClubRegistrationDetails {
  iconUrl : string;
  title : string;
  description : string;
  visibility : VisibilityType;
  type : ClubType;
  admins : Array<string>;
  participants : Array<string>;

  constructor(args : ClubRegistrationDetails){
    this.iconUrl = args.iconUrl;
    this.title = args.title;
    this.description = args.description;
    this.visibility = args.visibility;
    this.type = args.type;
    this.admins = args.admins;
    this.participants = args.participants;
  }
}