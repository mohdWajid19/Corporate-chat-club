export enum Gender {
  NotSpecified = 0,
  Male = 1,
  Female = 2
}