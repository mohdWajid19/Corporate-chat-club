export interface Clubs {
  id : string;
  iconUrl : string;
  title : string;
  description : string;
  isPublic : boolean;
  isClosed : boolean;
  createdBy : string;
  createdOn : Date;
  membersCount : number;
  isJoined : boolean;
  isRequested : boolean;
}