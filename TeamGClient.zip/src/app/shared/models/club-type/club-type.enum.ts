export enum ClubType {
  Closed = 0,
  Open = 1 
}