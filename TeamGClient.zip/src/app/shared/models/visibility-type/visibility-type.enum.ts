export enum VisibilityType{
  Private = 0,
  Public = 1 
}