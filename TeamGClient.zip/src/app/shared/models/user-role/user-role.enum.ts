export enum UserRole {
  GlobalAdmin = 0,
  ClubAdmin = 1,
  User = 2
}