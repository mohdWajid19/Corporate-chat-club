import { UserStatus } from "../user-status";

export class UserRegistrationDetails {
    firstName : string;
    middleName : string;
    lastName : string;
    displayName : string;
    phone : string;
    email : string;
    status : UserStatus;
    taggedClubs : Array<string>;

    constructor(args : UserRegistrationDetails) {
        this.firstName =args.firstName;
        this.middleName =args.middleName;
        this.lastName =args.lastName;
        this.displayName = args.displayName;
        this.phone = args.phone;
        this.email = args.email;
        this.status = args.status;
        this.taggedClubs = args.taggedClubs;
    }
}