export enum MaritalStatus {
  Divorced = 0,
  Widow = 1,
  Widower = 2,
  Single = 3,
  Married = 4,
  NotSpecified = 5
}