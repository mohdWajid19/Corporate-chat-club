import { ClubStatus } from "../club-status";
import { ClubType } from "../club-type";
import { VisibilityType } from "../visibility-type";

export interface ClubDetails {
  id : string;
  iconUrl : string;
  title : string;
  ownerId : string;
  visibility : VisibilityType;
  type : ClubType;
  description : string;
  createdOn : Date;
  status : ClubStatus;
  actionTakenBy : string;
  actionTakenOn : Date;
  reason : string;
  isMuted : boolean;
  isDeleted : boolean;
}