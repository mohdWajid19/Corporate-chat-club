import { UserRole } from "../user-role";
import { UserStatus } from "../user-status";

export interface UserDetails {
  id : string;
  firstName : string;
  middleName : string;
  lastName : string;
  displayName : string;
  phone : string;
  email : string;
  status : UserStatus;
  actionTakenBy : string;
  actionTakenOn : Date;
  reason : string;
  isDeleted : boolean;
  addedBy : string;
  addedOn : Date;
  role : UserRole;
}