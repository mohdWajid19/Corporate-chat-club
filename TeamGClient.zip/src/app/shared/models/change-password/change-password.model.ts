export class ChangePassword {
  userName : string;
  oldPassword : string;
  newPassword : string;

  constructor(args : ChangePassword) {
    this.userName = args.userName;
    this.oldPassword = args.oldPassword;
    this.newPassword = args.newPassword;
  }
}