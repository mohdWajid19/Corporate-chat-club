import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-club',
  templateUrl: './leave-club.component.html'
})

export class LeaveClubComponent {

}
