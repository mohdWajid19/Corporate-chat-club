import { Component } from '@angular/core';

@Component({
  selector: 'app-reactivate-user',
  templateUrl: './reactivate-user.component.html'
})

export class ReactivateUserComponent {

}
