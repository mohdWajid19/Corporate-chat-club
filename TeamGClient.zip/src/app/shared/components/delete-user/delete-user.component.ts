import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html'
})

export class DeleteUserComponent {

}
