import { Component } from '@angular/core';

@Component({
  selector: 'app-deactivate-user',
  templateUrl: './deactivate-user.component.html'
})

export class DeactivateUserComponent {

}
