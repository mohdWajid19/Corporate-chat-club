import { Component } from '@angular/core';

@Component({
  selector: 'app-add-club',
  templateUrl: './add-club.component.html'
})

export class AddClubComponent {

}
