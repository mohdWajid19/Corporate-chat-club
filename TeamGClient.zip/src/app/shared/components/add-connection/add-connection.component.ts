import { Component } from '@angular/core';

@Component({
  selector: 'app-add-connection',
  templateUrl: './add-connection.component.html'
})

export class AddConnectionComponent {

}
