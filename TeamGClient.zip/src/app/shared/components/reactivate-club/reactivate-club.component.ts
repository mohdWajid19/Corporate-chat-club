import { Component } from '@angular/core';

@Component({
  selector: 'app-reactivate-club',
  templateUrl: './reactivate-club.component.html'
})

export class ReactivateClubComponent {

}
