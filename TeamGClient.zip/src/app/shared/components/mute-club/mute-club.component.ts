import { Component } from '@angular/core';

@Component({
  selector: 'app-mute-club',
  templateUrl: './mute-club.component.html'
})

export class MuteClubComponent {

}
