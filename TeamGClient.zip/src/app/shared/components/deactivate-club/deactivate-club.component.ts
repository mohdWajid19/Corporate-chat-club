import { Component } from '@angular/core';

@Component({
  selector: 'app-deactivate-club',
  templateUrl: './deactivate-club.component.html'
})

export class DeactivateClubComponent {

}
