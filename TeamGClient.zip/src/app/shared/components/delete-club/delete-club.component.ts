import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-club',
  templateUrl: './delete-club.component.html'
})

export class DeleteClubComponent {

}
